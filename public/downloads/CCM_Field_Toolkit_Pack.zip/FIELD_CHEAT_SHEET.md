# Auditor's 1-Page Field Triage Cheat Sheet
## 5 Anomaly Tests in Excel (Triage & Evidence Rules)

Keep this open during fieldwork. Follow the exact verification rule when an exception is flagged.

---

### Test 1: Split POs (Circumventing DOA Limits)
* **Excel Logic:** Same vendor, same buyer, individual POs < $10k, occurring within 5 days, combined sum $\ge$ $10k.
* **Immediate Verification Rule:**
  1. Pull both PO line item descriptions.
  2. If descriptions read "Phase 1 / Phase 2", "Part A / Part B", or identical scope split into consecutive numbers $\rightarrow$ **Confirmed Finding**.
  3. *Interview Question to Buyer:* *"Was this split requested by the vendor, or was it issued as two orders to prevent procurement committee review?"*

---

### Test 2: Inactive Vendor Resuscitation & Bank Alteration
* **Excel Logic:** No transactions for >180 days, bank details updated within 30 days before payment disbursement.
* **Immediate Verification Rule:**
  1. Inspect the vendor master change log (`CDHDR`/`CDPOS` or equivalent).
  2. Check the independent call-back verification form.
  3. If bank change was made based on an email request without phone verification to the registered vendor CFO $\rightarrow$ **High-Risk Fraud / Unauthorized Redirection Finding**.

---

### Test 3: Near-Duplicate Invoices (Punctuation & Typos)
* **Excel Logic:** Same vendor, same amount, identical string after stripping hyphens, slashes, and spaces (`INV-1099` vs `INV 1099`).
* **Immediate Verification Rule:**
  1. Pull the bank payment clearing vouchers for both items.
  2. If two distinct bank transaction references exist $\rightarrow$ **Confirmed Double Payment (Immediate Cash Recovery)**.
  3. If one is cleared and one is reversed, check the reversal reason and identify who caught it (AP clerk or external vendor).

---

### Test 4: Off-Hours & Weekend Journal Entries
* **Excel Logic:** Entries posted Saturday/Sunday, or between 7:00 PM and 7:00 AM.
* **Immediate Verification Rule:**
  1. Filter out automated system accounts (`BATCH`, `SYSTEM`, `CRON`).
  2. For human User IDs, look at the debit/credit lines:
     * Manual credits to Revenue at 11:30 PM on the 31st $\rightarrow$ Revenue cutoff manipulation.
     * Manual debits to Prepayments / Suspense on Sunday $\rightarrow$ Expense deferral.
  3. *Trench Rule:* Legitimate routine entries are automated; late-night human entries are adjustments under pressure.

---

### Test 5: Suspicious Round-Sum Professional Fees
* **Excel Logic:** Fees $\ge$ $5,000, exactly divisible by $1,000 or $2,500, coded to Consulting, Legal, Advisory, or Marketing.
* **Immediate Verification Rule:**
  1. Review the voucher packet for physical proof of work: timesheets, final deliverables, pitch decks, formal legal memos.
  2. If the only attachment is a 1-page generic invoice stating *"For advisory services rendered as agreed"* without an approved contract or milestone sign-off $\rightarrow$ **Unsubstantiated Discretionary Spend Finding**.

---

### The Fieldwork Golden Rule
> **"Do not sample 25 random transactions to see if someone signed a box. Run these 5 tests across 100% of the transactions, extract the exceptions, and audit the exceptions."**
