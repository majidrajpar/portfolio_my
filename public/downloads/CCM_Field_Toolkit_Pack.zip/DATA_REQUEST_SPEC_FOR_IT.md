# Internal Audit Data Request Specification
## Telemetry Extraction for Continuous Control & Anomaly Testing

**To:** IT Systems Administrator / ERP Database Administrator / Finance Systems Lead  
**From:** Internal Audit & Risk Advisory  
**Subject:** Data Extraction Request: AP, Procurement, and General Ledger Telemetry  
**Format Required:** Raw, unformatted `.csv` or `.xlsx` flat tables (headers in Row 1, no merged cells, no subtotals, UTF-8).

---

### File 1: AP Payments & Invoices (`ap_invoices_extract.csv`)
*Target ERP Tables:* SAP (`BSEG`, `BSAK`, `BKPF`), Oracle (`AP_INVOICES_ALL`, `AP_PAYMENTS_ALL`), NetSuite (`Transactions: Bill`)

| Column Name | Data Type | Description / Notes |
| :--- | :--- | :--- |
| `Vendor_ID` | String / Int | System vendor master identifier |
| `Vendor_Name` | String | Legal vendor trading name |
| `Invoice_Number` | String | Raw invoice number as entered by AP clerk |
| `Invoice_Date` | Date (`YYYY-MM-DD`) | Date printed on the invoice |
| `Invoice_Amount` | Decimal (2 dp) | Total invoice gross amount |
| `Currency` | String | Transaction currency code (e.g., USD, AED, SAR) |
| `Payment_Reference_ID` | String | Bank payment clearing or check reference |
| `Payment_Date` | Date (`YYYY-MM-DD`) | Date payment cleared / disbursed |
| `GL_Account_Code` | String | Natural expense account code |
| `GL_Account_Name` | String | Expense account description (e.g., Legal, Consulting) |
| `Line_Description` | String | Free-text line narration or purchase purpose |
| `Created_By` | String | User ID who keyed the transaction |
| `Approved_By` | String | User ID who released the transaction for payment |
| `Created_Timestamp` | Datetime (`YYYY-MM-DD HH:MM:SS`) | **Mandatory:** Full system audit trail timestamp |

---

### File 2: Purchase Orders Line Items (`po_lines_extract.csv`)
*Target ERP Tables:* SAP (`EKKO`, `EKPO`), Oracle (`PO_HEADERS_ALL`, `PO_LINES_ALL`), NetSuite (`Purchase Orders`)

| Column Name | Data Type | Description / Notes |
| :--- | :--- | :--- |
| `PO_Number` | String | System purchase order number |
| `PO_Line_Number` | Int | Line item sequence number |
| `Vendor_ID` | String / Int | System vendor master identifier |
| `Vendor_Name` | String | Vendor name |
| `PO_Date` | Date (`YYYY-MM-DD`) | Date PO was created/approved |
| `PO_Amount` | Decimal (2 dp) | Line amount / total commitment |
| `PO_Description` | String | Line item description |
| `Created_By` | String | Buyer / Requester User ID |
| `Approved_By` | String | Final DOA Approver User ID |
| `PO_Status` | String | Open, Approved, Closed, Cancelled |

---

### File 3: Vendor Master & Bank Audit Log (`vendor_master_extract.csv`)
*Target ERP Tables:* SAP (`LFA1`, `LFBK`, `CDHDR`/`CDPOS`), Oracle (`AP_SUPPLIERS`, `IBY_EXT_BANK_ACCOUNTS`)

| Column Name | Data Type | Description / Notes |
| :--- | :--- | :--- |
| `Vendor_ID` | String / Int | System vendor master identifier |
| `Vendor_Name` | String | Legal vendor name |
| `Vendor_Status` | String | Active, Blocked, Inactive |
| `Bank_Account_Number` | String | Registered bank account or IBAN |
| `Bank_Details_Last_Updated` | Date (`YYYY-MM-DD`) | **Mandatory:** Timestamp of last bank master change |
| `Previous_Active_Date` | Date (`YYYY-MM-DD`) | Date of the last invoice/payment prior to audit period |
| `Tax_ID_TRN` | String | Corporate tax registration number |

---

### File 4: General Ledger Journal Entries (`gl_journals_extract.csv`)
*Target ERP Tables:* SAP (`FAGLFLEXA`, `BSEG`), Oracle (`GL_JE_LINES`, `GL_JE_HEADERS`)

| Column Name | Data Type | Description / Notes |
| :--- | :--- | :--- |
| `Journal_ID` | String | Journal voucher reference number |
| `Account_Code` | String | General Ledger account code |
| `Account_Name` | String | General Ledger account description |
| `Debit_Amount` | Decimal (2 dp) | Debit value |
| `Credit_Amount` | Decimal (2 dp) | Credit value |
| `Created_By` | String | User ID who drafted/posted the entry |
| `Post_Timestamp` | Datetime (`YYYY-MM-DD HH:MM:SS`) | **Mandatory:** Exact database commit timestamp |
| `Journal_Source` | String | Manual Journal (MJ), Subledger, Batch, Interface |
| `Description` | String | Journal narration / justification |

---

### Ready-to-Send Email Draft to IT

```text
Subject: Data Extraction Request: Internal Audit Anomaly Testing [Audit Period]

Hi [Name/IT Helpdesk],

In connection with our upcoming audit fieldwork, please extract the raw system tables for the period [Start Date] to [End Date] per the attached technical specification.

Requirements:
1. Format: Flat CSV files with column headers in Row 1.
2. Please do not apply summary aggregations, pivot groupings, or merged formatting.
3. Crucial: Ensure system audit trail timestamps (Date and Time: HH:MM:SS) and User IDs are included in the extract as specified.

Please upload the files to our secure audit folder: [Link]

Thank you,
Internal Audit & Risk Advisory Team
```
