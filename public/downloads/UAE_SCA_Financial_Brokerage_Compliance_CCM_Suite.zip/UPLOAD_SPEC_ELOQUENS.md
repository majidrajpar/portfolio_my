# Eloquens Upload Specification & Publisher Manifest
### Best Practice Listing: UAE SCA Brokerage Compliance & CCM Suite: Category 1 & 5 Policies, Daily Segregation Model & AML

**Platform URL:** [https://www.eloquens.com/contributions/create/docs](https://www.eloquens.com/contributions/create/docs)  
**Author Channel:** [https://www.eloquens.com/channel/majid-mumtaz](https://www.eloquens.com/channel/majid-mumtaz)  
**Author / Publisher:** Majid Mumtaz (CIA, ACA, FCCA, GRCP, GRCA, COSO ERM Certified)  
**Practice:** Veritux Consulting Network | Continuous Controls Monitoring & Risk Advisory  
**Staging Directory:** `11_UAE_SCA_Financial_Brokerage_Compliance_CCM_Suite`  

---

## 1. Eloquens Multi-Step Wizard Configuration

### Step 1: TITLE & ORIGINAL
- **Downloadable Best Practice Title:** `UAE SCA Brokerage Compliance & CCM Suite: Category 1 & 5 Policies, Daily Segregation Model & AML` *(Length: 96 chars, within 10-120 character limit)*
- **Original Eloquens URL:** Leave blank (Original publication).

### Step 2: DESCRIPTION, COVER & DOCUMENTS
- **Category:** `Strategy` -> `Corporate Governance / Risk Management & Compliance`
- **Filter Criteria:**
  * **Time to complete:** `More than 3 hours`
  * **Format of this Best Practice:** `Both (Quantitative tool + Presentation/Documentation)`
- **Certification of Publication Date:** Checked / Active (generates cryptographic authorship timestamp).
- **Primary Upload File:** `UAE_SCA_Financial_Brokerage_Compliance_CCM_Suite.zip`
- **Cover Image & Screenshot Previews (16:9 Aspect Ratio):**
- **Screenshot 1:** 1. Executive Summary & Audit Sign-Off Dashboard (Cover Image - 16:9)
- **Screenshot 2:** 2. Dual-Tier Daily Client Money Segregation Reconciliation Model (.xlsx)
- **Screenshot 3:** 3. SCA Master Compliance Manual & Statutory Governance Framework (.docx)
- **Screenshot 4:** 4. Federal Decree-Law No. (20) AML/CFT & Sanctions Compliance Program (.docx)
- **Screenshot 5:** 5. Event-Driven Continuous Controls Monitoring (CCM) Telemetry Pipeline (.docx)

### Step 3: METHODOLOGY
- **Accompanying Video:** Optional (can link YouTube `@AuditBitz` walkthrough).
- **Written Step-by-Step Methodology:** Turnkey 4-stage implementation framework (Calibration -> Data Ingestion -> Automated Scoring -> Executive Board Escalation).

### Step 4: PRICING (USD)
- **Publish for Free?** No (Commercial Best Practice)
- **Academy / Non-Profit License:** **$99**
- **Business License (Practitioner / Single Entity):** **$249**
- **Consulting License (Commercial Advisory / Multi-Entity):** **$499**
- **Discount Settings:** Inactive at launch (preserve premium price signal).

### Step 5: PROFILE
- **Author:** Majid Mumtaz (`channel/majid-mumtaz`)
- **Professional Headline:** Director of Internal Audit & Risk Advisory | CIA, ACA, FCCA, GRCP, COSO ERM

### Step 6: CONFIRM
- **Attestation:** Check *"I acknowledge that this is my own work and that it is accurate and appropriate for publication"*.

---

## 2. Short Description (Hook for Catalog Cards)

> **Instructions for Publisher:** Paste this concise summary into Eloquens `Short description` (`nvDescShort`).

```text
UAE SCA Brokerage Compliance & CCM Suite: Category 1 & 5 Policies, Daily Segregation Model & AML is an institutional-grade Excel operational model and continuous controls monitoring workbench built by Majid Mumtaz (CIA, ACA, FCCA, GRCP). Engineered with 100% macro-free native formulas, it replaces 25-sample compliance checklists with quantitative operational telemetry, mass-balance testing, and automated Critical Override governance logic to protect EBITDA.
```

---

## 3. Long Description (Rich Text / WYSIWYG Ready)

> **Instructions for Publisher:** Copy the text below and paste directly into Eloquens `Long description` (`nvDescLong`).

```markdown

### UAE SCA Category 1 & Category 5 Financial Brokerage Compliance Suite & CCM Model

Deploy a complete, institutional-grade regulatory compliance and Continuous Controls Monitoring (CCM) architecture for UAE Securities and Commodities Authority (SCA) licensed financial brokerages.

Engineered specifically for **Category 1 (Trading Broker in OTC Derivatives & Spot FX)** and **Category 5 (Financial Consultation & Analysis)** firms, this suite bridges statutory regulatory obligations with automated continuous telemetry.

#### Deliverables Manifest:
- **01 SCA Client Money Daily Segregation Reconciliation Model (.xlsx):** 5-tab macro-free Excel workbook executing dual-tier platform-to-ledger and external bank reconciliations, CBUAE concentration tests (>=60% domestic bank holding, <=40% clearing broker margin cap, <=50% single-bank concentration), and dynamic 10% firm buffer reserves.
- **6 Institutional Governance & Policy Documents (.docx):**
  1. `compliance_package_docx/00_Compliance_Package_Overview_and_Implementation_Guide.docx`
  2. `compliance_package_docx/01_SCA_Master_Compliance_Manual.docx`
  3. `compliance_package_docx/02_AML_CFT_Sanctions_Compliance_Program.docx`
  4. `compliance_package_docx/03_Client_Money_and_Asset_Segregation_Policy.docx`
  5. `compliance_package_docx/04_Conduct_of_Business_and_Retail_Protection_Policy.docx`
  6. `compliance_package_docx/05_Continuous_Controls_Monitoring_Telemetry_Spec.docx`
- **Master Implementation Guide & Annual Statutory Filing Calendar (.docx & .md)**
- **Commercial Licensing Agreement & Terms of Use (.md)**

#### Key Features:
- **100% Macro-Free & Secure:** Native Excel architecture with zero VBA macros or external script dependencies, ensuring instant IT security sign-off.
- **Turnkey White-Label Placeholders:** Pre-configured with `[Entity Name L.L.C.]`, `[Trading Name]`, and `[SCA License No.]` for rapid institutional adaptation.
- **Automated CCM Telemetry:** Event streaming schemas and production SQL queries for real-time surveillance of segregation deficits and market misconduct.

#### Granular 3-Tier Pricing:
- **Academic / Non-Profit License:** $99
- **Business License (Single Authorized Brokerage Entity):** $249
- **Consulting License (Commercial Advisory / Multi-Client Practice):** $499


---

#### Key Model Features:
- **100% Macro-Free & IT Safe:** Native Microsoft Excel (.xlsx) architecture with zero VBA macros or external script dependencies. Guarantees instant corporate IT security sign-off and frictionless endpoint deployment.
- **Quantitative Telemetry Ingestion:** Pre-built data intake schedules designed to ingest raw transactional data, sensor feeds, POS journals, and ERP ledger extracts.
- **Automated Critical Override Logic:** Mathematical governance circuit breaker that immediately collapses consolidated ratings to Unsatisfactory if catastrophic controls fail, eliminating executive whitewashing.
- **Board-Level Visual Dashboard:** Executive-ready scorecards and heatmaps formatted for presentation to the Chief Executive Officer, Chief Financial Officer, and Board Audit Committee.


## Author Credentials & Institutional Standing
- **Author & Architect:** Majid Mumtaz (CIA, ACA, FCCA, GRCP, GRCA, COSO ERM Certified)
- **Practice:** Director of Internal Audit & Risk Advisory / Audit Committee Secretary, Veritux Consulting Network
- **Executive Profile:** Former Director of Internal Audit & GRC at Kitopi; Group Director of Internal Audit & Risk at Al-Faisaliah Group; Internal Audit Lead at McDonald's Saudi Arabia; Big 4 Alumnus (KPMG, EY).
- **Thought Leadership:** Author of *The Audit Signal* (LinkedIn newsletter) and practitioner tools at `majidrajpar.github.io/portfolio_my`.
- **Core Philosophy:** Replacing retrospective 20-invoice sample compliance testing with automated 100% continuous controls monitoring (CCM) and operational telemetry directly connected to Board-level EBITDA protection.
- **Technical Integrity Guarantee:** 100% macro-free native Microsoft Excel formulas, open calculation architecture, editable Microsoft Word templates, vector PDFs, instant corporate IT and expense approval.

```

---

## 4. Tags & Search Keywords

> **Instructions for Publisher:** Copy and paste these tags into Eloquens `Further information / Keywords` field (`nvKeywords`).

```text
sca-compliance, uae-brokerage, category-1-broker, client-money-segregation, continuous-controls-monitoring, aml-cft-sanctions, cfd-forex-regulation, cbuae-regulations, fiduciary-controls, financial-brokerage
```

---

## 5. File Attachment Mapping & Upload Manifest

| Delivery Role | Filename | Format | File Description |
| :--- | :--- | :--- | :--- |
| **Primary Deliverable** | `UAE_SCA_Financial_Brokerage_Compliance_CCM_Suite.zip` | `.ZIP` | Main deliverable file uploaded to Eloquens. |
| **Companion Deliverable** | `01_SCA_Client_Money_Daily_Segregation_Reconciliation_Model.xlsx` | `.XLSX` | Deployment guide, documentation, or advisory license terms. |
| **Companion Deliverable** | `02_Retail_Appropriateness_and_Suitability_Scoring_Engine.xlsx` | `.XLSX` | Deployment guide, documentation, or advisory license terms. |
| **Companion Deliverable** | `03_SCA_Approved_Person_Register_and_Compliance_Monitoring_Plan.xlsx` | `.XLSX` | Deployment guide, documentation, or advisory license terms. |
| **Companion Deliverable** | `COMMERCIAL_LICENSE.md` | `.MD` | Deployment guide, documentation, or advisory license terms. |
| **Companion Deliverable** | `README.md` | `.MD` | Deployment guide, documentation, or advisory license terms. |

---

## 6. Eloquens Commercial Terms & Seller Policies
- **Revenue Split:** 85% Author / 15% Eloquens net revenue split (revenues minus third-party Stripe/PayPal processing fees).
- **Payout Terms:** Payouts wired within 15 days following the end of each calendar month (Net 15) to author's connected PayPal or Bank Account (IBAN).
- **Minimum Payout Threshold:** $80 USD. Balances below $80 roll over to the subsequent month.
- **Licensing Tiers:** Authors maintain three distinct tiers (Academic, Business, Consulting) capturing diverse buyer budgets without cannibalizing advisory fees.
- **Certificate of Publication:** Eloquens automatically timestamps and issues a digital Certificate of Publication, legally establishing first-date publication and defending intellectual property against copycats.
