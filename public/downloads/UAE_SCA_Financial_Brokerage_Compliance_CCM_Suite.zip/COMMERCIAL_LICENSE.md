# Commercial License & Terms of Use

**Asset:** UAE SCA Category 1 & Category 5 Financial Brokerage Compliance & Continuous Controls Monitoring (CCM) Architecture  
**Copyright:** © 2026 Majid Mumtaz, CIA, ACA (ICAEW), FCCA, GRCP, GRCA, COSO ERM Certified. All Rights Reserved.  
**Source & Licensing Portal:** [majidrajpar.github.io/portfolio_my](https://majidrajpar.github.io/portfolio_my) | [Gumroad](https://majidrajpar.gumroad.com/l/uae-sca-brokerage-compliance)

---

## 1. Grant of License by Tier

Your permitted scope of use depends strictly on the license tier purchased at checkout:

### Tier 1: Standard In-House Brokerage Practitioner License ($199 - $249 USD)
- **Permitted Scope:** Grants one (1) authorized financial brokerage legal entity operating in the United Arab Emirates (onshore UAE licensed under SCA, or operating within the DIFC / ADGM financial free zones) the non-exclusive, perpetual, worldwide right to customize, adapt, and deploy the compliance manuals, AML/CFT sanctions policies, client money segregation frameworks, conduct of business retail protection rules, continuous controls monitoring (CCM) telemetry schemas, and audit workpapers internally across its Compliance, Risk, Treasury, Dealing Desk, and Operations departments.
- **Internal Distribution Rights:** You may share customized versions internally with your Board of Directors, Audit & Risk Committee, Compliance Officer, MLRO, Finance/Treasury team, internal auditors, and external statutory compliance auditors or regulatory examiners (including the Securities and Commodities Authority, CBUAE, or executive assessors) solely for the purpose of governing, operating, and auditing your single licensed brokerage entity.
- **Restrictions:** You may **not** use the Standard Practitioner License to deploy the suite across multiple distinct corporate brokerage legal entities, affiliated holding group entities, nor may you use it in external client consulting, co-sourced compliance advisory, or outsourced MLRO/Compliance Officer engagements.

### Tier 2: Enterprise Multi-Entity & GRC Advisory License ($449 - $499 USD)
- **Permitted Scope:** Grants multi-entity financial brokerage holding groups, financial conglomerates, law firms, GRC consultancies, and compliance advisory practices the non-exclusive, perpetual, worldwide right to customize and deploy the suite across:
  1. Unlimited wholly or majority-owned corporate brokerage subsidiaries and operating legal entities within a single corporate holding group; **or**
  2. External client engagements where you act as an outsourced Compliance Officer, MLRO, Regulatory Counsel, Risk Advisory Partner, or Fractional CAE delivering tailored statutory compliance, AML/CFT programs, and CCM surveillance architectures to client brokerages.
- **Client Deliverable Rights:** Advisory practitioners holding the Enterprise License may deliver customized, client-specific adaptations of these compliance manuals, client asset policies, AML procedures, and CCM technical specifications to their active client engagements as part of a bona fide professional services contract.

---

## 2. Universal Restrictions (Applicable to All Tiers)

Regardless of the license tier purchased, the Licensee shall **not**:
1. **Resell or Redistribute as a Standalone Template or Competing Toolkit:** Sell, license, sublicense, rent, auction, or distribute the raw or lightly modified templates, policies, schemas, or workbooks as a standalone digital download, template bundle, course attachment, or commercial toolkit on any marketplace (including Flevy, Eloquens, Gumroad, GitHub, or proprietary websites).
2. **SaaS or Commercial Surveillance Software Bundling:** Embed the underlying CCM telemetry SQL triggers, Kafka/Flink event schemas, or segregation calculation logic into a commercial SaaS platform, regtech product, or proprietary trading/compliance management software package for resale without a separate OEM commercial licensing agreement with the author.
3. **Public Repository Hosting:** Upload editable `.docx`, `.xlsx`, `.sql`, `.pdf`, or `.md` files from this suite to any public GitHub repository, public cloud bucket, or open-access document-sharing platform.

---

## 3. Statutory Assurance & Professional Liability Disclaimer

1. **No Statutory Certification or Regulatory Pre-Approval:** This suite provides institutional compliance governance documentation, automated CCM telemetry specifications, and operational testing protocols. While engineered to reflect the SCA Rulebook (including Decisions No. 13/2021 and No. 01/R.M of 2023), UAE Federal Decree-Law No. (20) of 2018 (AML/CFT), Cabinet Decision No. (10) of 2019, CBUAE client asset standards, and UAE FIU / EOCN mandates, nothing in this package constitutes formal legal advice or guarantees regulatory pre-clearance or statutory licensing approval from the Securities and Commodities Authority (SCA), Central Bank of the UAE (CBUAE), Executive Office for Control & Non-Proliferation (EOCN), or the UAE Financial Intelligence Unit (FIU).
2. **Licensee Calibration Responsibility:** Quantitative thresholds, leverage caps (30:1 to 2:1), daily client money buffer levels (minimum 10%), appropriateness scoring gates (70%), and automated CCM detection rules must be calibrated and maintained by the Licensee in strict accordance with the firm's specific category of SCA license, risk appetite, operating systems, and prevailing regulatory circulars.
3. **"As-Is" Provision & Limitation of Liability:** All files, schemas, and templates in this suite are provided "as-is" without warranty of any kind, express or implied. In no event shall the author or Veritux Consulting Network be liable for any direct, indirect, incidental, regulatory fines, sanctions, or commercial damages arising from the implementation, configuration, or operational use of this architecture.

---

## 4. Inquiries & Custom Advisory Deployment

For institutional licensing inquiries, bespoke regulatory calibration, SCA licensing readiness reviews, or Continuous Controls Monitoring (CCM) deployment advisory, contact:

**Majid Mumtaz, CIA, ACA (ICAEW), FCCA, GRCP, GRCA, COSO ERM Certified**  
Director of Internal Audit & Risk Advisory / Audit Committee Secretary  
Veritux Consulting Network  
Portfolio & Architecture: [majidrajpar.github.io/portfolio_my](https://majidrajpar.github.io/portfolio_my)  
LinkedIn: [linkedin.com/in/majid-m-4b097118](https://www.linkedin.com/in/majid-m-4b097118/)  
Email: [majidrajpar@gmail.com](mailto:majidrajpar@gmail.com)
