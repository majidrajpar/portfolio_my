# [Entity Name L.L.C.]
# Anti-Money Laundering (AML), Counter-Financing of Terrorism (CFT), and Sanctions Compliance Program
# Trade Name: [Trading Name] | SCA License: [SCA License No.]

## 1. Statutory Legislative Framework and Regulatory Authorities

### 1.1 UAE Federal Legal Framework
[Entity Name L.L.C.] (trading as [Trading Name], the Firm) implements this Anti-Money Laundering, Counter-Financing of Terrorism, and Sanctions Compliance Program pursuant to the mandatory requirements of UAE federal legislation, ministerial decisions, and regulatory rulebooks:

Federal Decree-Law No. (20) of 2018 on Anti-Money Laundering and Combating the Financing of Terrorism and Financing of Illegal Organisations, as amended by Federal Decree-Law No. (26) of 2021.

Cabinet Decision No. (10) of 2019 on the Executive Regulations of Federal Decree-Law No. (20) of 2018.

Cabinet Decision No. (74) of 2020 regarding the UAE Terrorism Lists Regulation and Implementation of UN Security Council Resolutions on the Prevention and Suppression of Terrorism and Financing of Terrorism, and Prevention, Suppression and Disruption of Proliferation of Weapons of Mass Destruction.

Cabinet Decision No. (109) of 2023 on the Regulation of the Real Beneficiary Procedures (superseding Cabinet Decision No. 58 of 2020).

Federal Decree-Law No. (46) of 2021 on Electronic Transactions and Trust Services, governing digital identity verification standards.

Rules, Regulations, and Circulars of the Securities and Commodities Authority (SCA) governing financial crime prevention, client verification, and risk-based controls for Category 1 and Category 5 authorized firms.

Operational Guidelines and Directives issued by the UAE Financial Intelligence Unit (FIU) and the Executive Office for Control and Non-Proliferation (EOCN).

### 1.2 Enterprise Policy Statement
The Firm enforces an absolute zero-tolerance policy toward money laundering, terrorist financing, proliferation financing, sanctions evasion, and associated financial crime. The Firm conducts business exclusively with verified counterparties, natural persons, and legal entities whose identities, beneficial ownership hierarchies, tax residences, and legitimate sources of wealth and funds have been established beyond reasonable doubt. The commercial objective of onboarding trading clients or generating transactional commission shall never supersede statutory AML/CFT controls.

---

## 2. Risk-Based Approach (RBA) and Enterprise-Wide Risk Assessment

### 2.1 Enterprise-Wide Risk Assessment (EWRA) Methodology
The Firm executes an Enterprise-Wide Risk Assessment at least annually, or immediately upon material shifts in product offerings, jurisdictional expansions, or regulatory directives. The EWRA evaluates the inherent risk exposure of the Firm, the operational effectiveness of mitigating controls, and the resulting residual risk across four statutory risk pillars:

Customer Risk: Evaluating the risk profiles of retail clients, high-net-worth individuals, corporate entities, trusts, unregulated funds, and politically exposed persons.

Geographic Risk: Assessing exposure to high-risk jurisdictions identified by the Financial Action Task Force (FATF), jurisdictions subject to international sanctions, and jurisdictions with deficient AML/CFT legal systems.

Product and Service Risk: Analyzing the inherent money laundering and fraud vulnerabilities of leveraged OTC derivatives, contracts for differences (CFDs), spot foreign exchange, and API-based automated trading terminals.

Channel and Delivery Risk: Evaluating the vulnerabilities associated with non-face-to-face digital onboarding, third-party payment service providers (PSPs), multi-currency virtual bank accounts, and remote identity verification software.

### 2.2 Customer Risk Categorization and Elimination of SDD for Leveraged Products
Due to the inherent velocity, leverage multipliers, and capital mobility of over-the-counter derivatives and spot foreign exchange, Simplified Due Diligence (SDD) is strictly prohibited for any retail natural person or corporate client trading leveraged instruments. Standard Customer Due Diligence (CDD) constitutes the non-negotiable statutory baseline.

Every prospective client is assigned an objective AML risk rating (Medium, High, or Prohibited) upon registration by an automated algorithmic risk engine. The risk matrix evaluates:

Country of citizenship, nationality, incorporation, and physical tax residence.

Legal structure complexity, including multi-layered holding companies, nominee shareholders, or trusts.

Client occupation, nature of employment, industry sector, or corporate line of business.

Anticipated trading turnover, initial funding velocity, and selected funding rails.

Adverse media findings, screening results against global enforcement lists, and commercial credit databases.

```
+---------------------------------------------------------------------------------------------------+
|                                 CUSTOMER RISK ASSESSMENT MATRIX                                   |
+-------------------+-----------------------------------+-------------------------------------------+
| Risk Tier         | Onboarding Criteria               | Due Diligence Mandate                     |
+-------------------+-----------------------------------+-------------------------------------------+
| Medium Risk       | Standard retail investors; UAE    | Standard Customer Due Diligence (CDD);    |
| (Statutory Floor) | residents and FATF-compliant      | verified biometric digital identity;      |
|                   | foreign jurisdictions; trading    | proof of residential address; verified    |
|                   | turnover < AED 250,000 monthly;   | source of funds; review every 24 months.  |
|                   | verified salaried employment.     | [Simplified Due Diligence Disallowed].    |
+-------------------+-----------------------------------+-------------------------------------------+
| High Risk         | Non-resident individuals; complex | Enhanced Due Diligence (EDD); certified   |
|                   | corporate structures; PEPs and    | source of wealth documents; Senior Exec / |
|                   | close associates; high turnover;  | MLRO formal approval required; review     |
|                   | high-risk industries.             | every 12 months or continuous monitoring. |
+-------------------+-----------------------------------+-------------------------------------------+
| Prohibited        | Sanctioned persons; residents of  | Immediate onboarding rejection; asset     |
|                   | FATF blacklisted jurisdictions;   | freeze if funds received; mandatory EOCN/ |
|                   | bearer share entities; anonymous. | goAML notification within 24 hours.       |
+-------------------+-----------------------------------+-------------------------------------------+
```

---

## 3. Customer Due Diligence (CDD) and Enhanced Due Diligence (EDD)

### 3.1 Timing of Due Diligence
No client account shall be activated for trading, nor shall any funds be accepted into segregated client bank accounts, until all customer due diligence procedures, identity verifications, sanctions screenings, and UBO disclosures are completed, validated, and approved in writing or automated system clearance.

### 3.2 Standard Due Diligence: Natural Persons
For individual retail and professional clients, the Compliance Department must collect, inspect, and verify the following minimum records:

Full legal name, residential address, date of birth, nationality, and national identification number.

A clear, high-resolution color copy of a valid Passport or national identity card (for UAE residents, a valid Emirates ID card verified electronically through the Federal Authority for Identity, Citizenship, Customs and Port Security (ICP) or UAE PASS framework).

Proof of residential address issued within the preceding three (3) months (utility bill, municipal tax statement, certified lease contract, or local bank statement).

Electronic biometric facial verification (liveness detection conforming to ISO/IEC 30107-3) cross-referenced against the identity document photograph.

Written declaration of the intended purpose of the account, anticipated trading frequency, expected deposit volumes, and legitimate source of funds.

### 3.3 Enhanced Due Diligence (EDD)
Enhanced Due Diligence is mandatory for all clients classified as High Risk, including non-resident retail clients, clients operating in high-risk geographic territories, corporate accounts with non-standard ownership layers, and Politically Exposed Persons. EDD requirements comprise:

Verification of Source of Wealth (SoW): Documented evidence demonstrating the origin of the client's cumulative net worth (audited financial statements, certified tax filings, corporate dividend certificates, property sale contracts, inheritance distributions, or executive employment contracts accompanied by bank statements reflecting cumulative savings).

Verification of Source of Funds (SoF): Documented evidence verifying the origin of the specific capital allocated to fund the margin trading account. The originating bank account must be maintained in the client's exact legal name at a regulated financial institution.

Mandatory MLRO and Senior Management Sign-Off: Accounts subject to EDD cannot be approved by operational onboarding analysts. Formal approval must be granted in writing by the MLRO and ratified by Senior Management.

Dynamic Transactional Monitoring: Setting bespoke transactional threshold alerts on trading volume, deposit frequency, and platform velocity.

### 3.4 Verification of Legal Entities and Complex Corporate Structures
For corporate entities, institutional trading desks, and partnerships, the Firm requires:

Certified copy of the Certificate of Incorporation, Commercial Trade License, or equivalent statutory charter issued by the competent commercial registrar.

Memorandum and Articles of Association, partnership agreements, or constitutional charters detailing corporate objectives and operational powers.

Certificate of Good Standing or official corporate registry extract issued within the preceding ninety (90) days.

Register of Directors and Register of Shareholders, verifying legal ownership and board composition.

Board Resolution formally approving the establishment of the trading account with the Firm and granting explicit trading and banking authority to designated Authorized Signatories.

Full CDD documentation for all Authorized Signatories, including passport copies, national IDs, and specimen signatures.

Complete resolution of the ownership chain to identify all natural persons holding beneficial ownership.

---

## 4. Ultimate Beneficial Ownership (UBO) Transparency

### 4.1 Statutory Definition and Threshold
Pursuant to Cabinet Decision No. (109) of 2023 on the Regulation of the Real Beneficiary Procedures, the Firm defines an Ultimate Beneficial Owner (UBO) as the natural person who ultimately owns or controls the legal entity, directly or indirectly, through:

Ownership of a controlling equity stake or voting rights in the legal entity equal to or exceeding twenty-five percent (25%) of the entity's total shares or voting rights.

Holding the ultimate right, through contractual agreements, constitutional documents, or family associations, to appoint or dismiss the majority of the Board of Directors or managing executives.

Exercising actual de facto control over the management, strategic operations, capital disbursements, or legal decisions of the entity through any other means.

```
       +--------------------------------------------------------------+
       |   Corporate Client: ABC Trading Global FZE (UAE Registered)   |
       +--------------------------------------------------------------+
                                      |
         +----------------------------+----------------------------+
         | 60% Equity Holding                                      | 40% Equity Holding
         v                                                         v
+-----------------------------+                           +-----------------------------+
| Holding Corp X (Cayman Is.) |                           | Holding Corp Y (BVI)        |
+-----------------------------+                           +-----------------------------+
         |                                                         |
         | 100% Equity Holding                                     | 100% Equity Holding
         v                                                         v
+-----------------------------+                           +-----------------------------+
| Natural Person A            |                           | Natural Person B            |
| (60% Indirect Ownership)    |                           | (40% Indirect Ownership)    |
| -> STATUTORY UBO (>= 25%)   |                           | -> STATUTORY UBO (>= 25%)   |
| -> Full CDD/EDD Required    |                           | -> Full CDD/EDD Required    |
+-----------------------------+                           +-----------------------------+
```

### 4.2 Cascading Identification Methodology
Where no natural person meets the 25% ownership or direct control criteria, or where doubt persists as to whether the natural persons identified are the actual beneficial owners:

The Firm investigates and identifies the natural persons who exercise ultimate effective control over the legal person through intermediate corporate vehicles, debt covenants, or voting trusts.

If no natural person is identified under the ownership or control tests, the Firm identifies and verifies the natural person who holds the position of Senior Managing Official (e.g., Chief Executive Officer, Managing Director, or Executive Board Member).

The Firm maintains an unredacted Register of Beneficial Owners for every corporate account, recording full legal names, passport details, nationality, date and place of birth, residential address, date on which ownership was acquired, and the exact percentage of equity held.

Corporate structures involving bearer shares, nominee shareholders, or corporate directors are strictly prohibited unless the underlying shares are immobilized under statutory custodian escrow approved by the SCA.

---

## 5. Politically Exposed Persons (PEPs) and High-Risk Jurisdictions

### 5.1 Identification and Classification of PEPs
A Politically Exposed Person (PEP) is any natural person who is or has been entrusted with prominent public functions, including:

Foreign PEPs: Heads of State, heads of government, senior politicians, government ministers, members of parliament, judicial authorities, senior military commanders, senior executives of state-owned enterprises, and senior political party officials of foreign jurisdictions.

Domestic PEPs: Individuals entrusted with prominent public functions within the United Arab Emirates, including federal and local government dignitaries, senior judicial officers, armed forces leadership, and board members of UAE sovereign entities.

International Organization PEPs: Directors, deputy directors, and members of the board or equivalent functions of international intergovernmental organizations.

Family Members and Close Associates (RCA): Spouses, children, parents, siblings, and known business partners or joint beneficial owners linked to a primary PEP.

### 5.2 Mandatory Controls and Senior Management PEP Approval
Pursuant to Article 15(1)(b) of Cabinet Decision No. (10) of 2019, the onboarding or ongoing maintenance of any PEP account is subject to strict governance protocols:

Mandatory Senior Management Approval: Prior to opening an account or executing any deposit transaction for a PEP or RCA, the Firm must obtain formal written approval from Senior Management (Chief Executive Officer or the Executive Committee), issued upon the formal written recommendation and risk review of the MLRO.

Source of Wealth and Funds Verification: Comprehensive identification and independent third-party verification of the customer's total Source of Wealth and the immediate Source of Funds must be completed and documented before approval.

Continuous Enhanced Monitoring: Application of Enhanced Due Diligence and automated transaction monitoring configured with lowered anomaly thresholds.

12-Month Post-Tenure Monitoring Rule: An individual who ceases to hold a prominent public function remains classified as a PEP and subject to PEP-level enhanced due diligence and monitoring for a minimum period of twelve (12) months following the date of stepping down. Beyond twelve months, the MLRO conducts a documented risk assessment evaluating residual influence, ongoing political connections, and asset exposure before re-classifying the client to standard risk tiers.

---

## 6. Sanctions Compliance: UN Consolidated List and UAE Local Terrorist List

### 6.1 Regulatory Framework and Executive Office Directives
Pursuant to Cabinet Decision No. (74) of 2020 and directives issued by the Executive Office for Control and Non-Proliferation (EOCN), the Firm maintains an automated, real-time sanctions screening architecture to ensure immediate compliance with:

The UAE Local Terrorist List issued by the UAE Cabinet and managed by the Supreme Council for National Security.

The United Nations Security Council (UNSC) Consolidated Sanctions List, encompassing resolutions targeting terrorism, terrorist financing, proliferation financing, and targeted sovereign regimes.

Autonomous international sanctions regimes, including lists administered by the United States Office of Foreign Assets Control (OFAC), the European Union (EU), and the United Kingdom His Majesty's Treasury (HMT), where applicable to clearing currencies or intermediary banking rails.

### 6.2 Screening Mechanics and Algorithmic Controls
Real-Time Onboarding Screening: The onboarding engine executes real-time fuzzy-matching screening (utilizing Jaro-Winkler, Levenshtein, and phonetic algorithms with a similarity tolerance configured at 85% or higher) against prospective client names, aliases, dates of birth, nationalities, identification numbers, and beneficial owners before account creation.

Continuous Daily Batch Screening: The entire existing client database, authorized signatories, UBOs, and registered bank account beneficiaries are screened daily against updated lists published by the EOCN and UNSC.

Payment and Transfer Screening: Every inbound and outbound fund transfer, card deposit, or bank wire is screened in real time against sanctions lists prior to credit to the client account or release from the segregated client bank account.

### 6.3 Confirmed Sanctions Match Protocol and Derivative Liquidation
Under Cabinet Decision No. (74) of 2020, upon identifying a confirmed match (true positive) against the UAE Local Terrorist List or UN Sanctions List, the Firm must execute statutory asset freezing actions immediately without delay, and in all cases within twenty-four (24) hours of the list update:

Immediate Freezing of Accounts: The system instantly revokes all digital platform credentials, API access keys, and trading privileges, blocking all inbound deposits and outbound disbursements without prior notice to the client.

Derivative Liquidation Protocol: To prevent unmonitored market exposure, variable margin erosion, or default across clearing venues during the freeze period, the Dealing Desk, under direct oversight of the MLRO and Risk Officer, immediately liquidates all open leveraged OTC derivatives and spot foreign exchange positions at prevailing market prices.

Blocked Escrow Suspense Account: The net liquidated cash balance resulting from position closures, together with all unencumbered client cash, is transferred immediately to an isolated, blocked, non-interest-bearing escrow suspense ledger maintained at a CBUAE-licensed commercial bank. The funds remain strictly frozen under regulatory lock.

Dual Regulatory Reporting within 24 Hours: The MLRO must submit a formal Fund Freeze Report (FFR) or Partial Name Match Report (PNMR) simultaneously to:
- The Executive Office for Control and Non-Proliferation (EOCN) via the official EOCN TFS portal.
- The UAE Financial Intelligence Unit (FIU) via the goAML portal.

Strict Confidentiality: All personnel must maintain absolute confidentiality and refrain from communicating with the customer or any unauthorized third party regarding the listing or freezing action, adhering strictly to anti-tipping-off provisions.

---

## 7. Introducing Brokers (IBs) and Third-Party Reliance Governance

### 7.1 Statutory Governance under Article 19
Pursuant to Article 19 of Cabinet Decision No. (10) of 2019, where the Firm utilizes or accepts client introductions from Introducing Brokers (IBs) or third-party intermediaries, the Firm enforces strict regulatory safeguards:

Initial Due Diligence and Vetting: Prior to entering into any commercial introduction agreement, the Compliance Department and MLRO execute comprehensive due diligence on the IB, evaluating corporate registration, regulatory licensing, beneficial ownership, reputational history, and AML/CFT policies.

Prohibition of Omnibus Client Accounts: Introducing Brokers are strictly prohibited from holding, operating, or pooling client funds in omnibus accounts. Every client introduced by an IB must be onboarded directly as an individual client of the Firm, undergoing full standard CDD/EDD verification.

Prohibition of Third-Party Fund Routing: Introducing Brokers are strictly prohibited from receiving, handling, holding, or routing client trading funds. All client deposits and withdrawals must flow directly between the client's verified bank account and the Firm's Client Segregated Trust Bank Account. Zero funding from IB corporate accounts or wallets is permitted.

Ultimate Legal Liability: The Firm retains ultimate legal, regulatory, and fiduciary responsibility for customer identification, verification, and AML/CFT compliance. Reliance on third-party introductions or documentation does not absolve the Firm of its statutory obligations under UAE law.

Continuous IB Surveillance: The Compliance Department conducts quarterly reviews of IB client portfolios to detect rebate churning, abnormal volume concentrations, or collusive trading patterns.

---

## 8. Transaction Monitoring, CFD/Forex Red Flags, and Typologies

### 8.1 Automated Real-Time and Post-Trade Surveillance
The Firm deploys automated transaction monitoring engines that ingest platform tick data, order execution streams, deposit ledgers, withdrawal queues, and customer demographic data. The system generates automated risk tickets based on pre-calibrated behavioral typologies and quantitative thresholds.

```
       +--------------------------------------------------------------+
       |   Automated Core Surveillance Engine (Real-Time Ingestion)   |
       +--------------------------------------------------------------+
             |                     |                     |
             v                     v                     v
   +-------------------+ +-------------------+ +-------------------+
   |  Payment & Banking| | Platform Trading  | | Profile & Velocity|
   |  Surveillance Desk| | Surveillance Desk | | Surveillance Desk |
   +-------------------+ +-------------------+ +-------------------+
             |                     |                     |
             +---------------------+---------------------+
                                   |
                                   v
             +-------------------------------------------+
             |   Automated Rules & Typology Detection    |
             +-------------------------------------------+
               - Third-Party Depositor Attempt
               - Card BIN Velocity / Token Collisions
               - Rapid Deposit-Withdrawal (Churning)
               - IB Rebate Churning / Zero-Risk Volume
               - Cross-Broker Mirror Hedging
               - Structuring / Smurfing (< AED 50,000)
               - Dormant Account Instant Capital Injection
                                   |
                                   v
             +-------------------------------------------+
             | MLRO Adjudication & goAML Case Management |
             +-------------------------------------------+
```

### 8.2 Leveraged Derivative and Forex Red Flag Typologies
Compliance analysts, dealing desk staff, and the automated surveillance engine monitor for specific financial crime typologies:

Rapid Deposit-Withdrawal Cycles (Turnover Washing): A client deposits substantial funds into the segregated account, executes minimal or negligible derivative trading volume (e.g., opening and closing fractional CFD lots within seconds to simulate legitimate trading activity), and immediately requests a full withdrawal to an alternate bank account or payment rail.

Card BIN Velocity and Token Collisions: Rapid deployment of multiple distinct payment card Bank Identification Numbers (BINs) from diverse geographic issuers or institutions on a single client account, or the reuse of identical card token hashes and device fingerprints across multiple seemingly unrelated client accounts.

Introducing Broker (IB) Rebate Churning: Coordinated high-frequency trading between an IB and affiliated client accounts executing high volumes of offsetting or zero-duration CFD trades designed solely to generate contractual volume rebates, commissions, or affiliate payouts without bona fide investment intent.

Cross-Broker Mirror Hedging: Accounts opening aggressive, unhedged directional positions in volatile contracts while simultaneously holding perfectly offsetting opposite positions on a competitor platform, designed to transfer illicit balances across brokers or exploit credit card float through asymmetric liquidation.

Third-Party Funding Attempts: Inbound deposit instructions originating from a bank account, credit card, or payment provider where the remitter name does not identically match the verified legal name of the onboarding client. Outbound withdrawal requests directed to third-party bank accounts, unverified wallets, or unrelated commercial entities.

Structured Deposits (Smurfing): A series of multiple incoming fund transfers, credit card transactions, or e-wallet credits initiated within a compressed window (e.g., within 48 to 72 hours), each deliberately calibrated just beneath statutory declaration thresholds or banking limits (such as consecutive deposits of AED 49,000 or USD 9,900).

Abnormal Account Velocity Post-Dormancy: An account that has maintained zero balance or remained inactive for over one hundred and eighty (180) days suddenly receives a massive capital injection followed immediately by aggressive, outsized margin exposure or urgent withdrawal demands.

Unusual Profit and Loss Transfers (Collusive Trading): Two or more client accounts established from identical IP subnets or hardware MAC addresses executing offsetting OTC contracts in illiquid derivative pairs at extreme spreads, intentionally shifting capital from one account to another under the guise of speculative trading losses.

---

## 9. Internal Reporting and goAML Submission Workflows

### 9.1 Internal Suspicion Reporting (ISR)
Every employee, contractor, or officer of the Firm is legally obligated to submit an immediate Internal Suspicion Report (ISR) to the MLRO whenever they detect, identify, or suspect that funds, assets, or attempted transactions involve the proceeds of crime, money laundering, or terrorist financing.

The ISR must be filed electronically through the confidential internal compliance management portal within four (4) hours of discovering the suspicious indicator.

The ISR must specify the full transaction details, the underlying red flags, customer responses, and any supporting documentation.

The filing employee is strictly prohibited from informing the customer, line managers, or peers about the submission.

```
+---------------------------------------------------------------------------------------------------+
|                            INTERNAL SUSPICION TO goAML WORKFLOW                                    |
+---------------------------------------------------------------------------------------------------+
| [1] Alert Triggered: Surveillance Engine / Employee Detection                                    |
|     -> Automated ticket generated or Internal Suspicion Report (ISR) logged.                      |
+---------------------------------------------------------------------------------------------------+
| [2] MLRO Initial Review (Within 24 Hours)                                                         |
|     -> Account placed under Enhanced Monitoring; immediate temporary freeze on outbound requests.  |
+---------------------------------------------------------------------------------------------------+
| [3] Investigation & Source of Wealth Analysis                                                    |
|     -> Evaluation of historical trades, deposit lineage, IP logs, and economic rationale.         |
+---------------------------------------------------------------------------------------------------+
| [4] MLRO Adjudication Decision                                                                    |
|     -> Grounds for Suspicion Found: Proceed to Step 5.                                            |
|     -> False Positive / No Suspicion: Documented grounds filed in Internal Audit File.            |
+---------------------------------------------------------------------------------------------------+
| [5] Regulatory Submission (Within 24-48 Hours of Confirmation)                                    |
|     -> STR / SAR filed with UAE FIU via goAML portal.                                             |
|     -> FFR / PNMR filed with EOCN via TFS portal (if sanctions match).                            |
+---------------------------------------------------------------------------------------------------+
```

### 9.2 FIU Reporting Mechanics via goAML Portal
The MLRO evaluates every internal suspicion report. Where reasonable grounds for suspicion exist, the MLRO must formulate and submit an external regulatory report to the UAE Financial Intelligence Unit via the integrated goAML platform:

Suspicious Transaction Report (STR): Lodged when an actual transaction, deposit, trade, or withdrawal has occurred and exhibits indicators of money laundering, predicate offenses, or illicit origin.

Suspicious Activity Report (SAR): Lodged when suspicious activity, attempted transactions, abnormal behavioral patterns, or forged identity submissions have been detected, regardless of whether funds were successfully transferred.

The goAML submission must contain the full XML schema or web entry comprising complete customer demographics, KYC documentation, full transactional ledgers, associated bank account details, IP connection logs, and an exhaustive narrative describing the rationale for suspicion and the typologies identified.

Submissions must be finalized and transmitted to the FIU without delay, and in no event later than forty-eight (48) hours following the confirmation of suspicion by the MLRO.

---

## 10. Statutory Prohibition of Tipping-Off and Legal Protections

### 10.1 Prohibition of Tipping-Off
Pursuant to Article 17 and Article 25 of Federal Decree-Law No. (20) of 2018, it is a severe criminal offense for any director, officer, or employee of the Firm to disclose, hint, or communicate, directly or indirectly, to the client, the beneficial owner, or any third party that:

An Internal Suspicion Report has been generated or submitted to the MLRO.

A transaction or account is under investigation by the compliance team, the MLRO, or domestic law enforcement.

An STR or SAR has been filed with the UAE Financial Intelligence Unit via goAML.

The FIU, the SCA, or police authorities have issued an inquiry, data request, or inspection order regarding the account.

Any individual who breaches this prohibition is liable under UAE Federal Law to criminal prosecution, substantial penal fines, and mandatory imprisonment, in addition to immediate summary dismissal from the Firm.

### 10.2 Statutory Immunity and Whistleblower Protection
Pursuant to Article 27 of Federal Decree-Law No. (20) of 2018, no director, officer, or employee of the Firm shall be held criminally, civilly, or administratively liable for any breach of professional secrecy, client confidentiality, or contractual obligations resulting from reporting suspicious transactions in good faith to the MLRO or the UAE FIU.

---

## 11. AML/CFT Governance, Independent Audit, and Employee Training

### 11.1 Independent External AML Audit (Statutory June 30 Deadline)
The Firm mandates an independent, objective external audit of its AML/CFT and Sanctions Compliance Program at least once every twelve (12) months. The audit must be executed by an SCA-approved, qualified external auditing firm with specialized financial crime accreditation.

The audit scope evaluates:

Operational efficacy of CDD, EDD, IB governance, and UBO verification protocols.

Soundness and calibration of automated transaction monitoring rules and threshold parameters.

Accuracy, completeness, and timeliness of goAML filings and internal suspicion registers.

Adequacy of staff resourcing and independence of the MLRO function.

The final written audit report, accompanied by management responses and a tracked remediation matrix, is submitted to the Board Audit and Risk Committee, the SCA, and the UAE FIU by no later than June 30 of each calendar year.

### 11.2 Mandatory Training Curriculum
All permanent, temporary, and contracted personnel must undergo structured AML/CFT training upon onboarding and annually thereafter:

New Hire Induction: Mandatory training completed within fourteen (14) days of commencement, covering basic legal requirements, red flags, tipping-off prohibitions, and internal reporting channels.

Front-Office and Dealing Desk Modules: Advanced training on market manipulation typologies, OTC derivative money laundering schemes, wash trading detection, IB rebate churning, and third-party payment identification.

Compliance and Operations Modules: Technical training on goAML report composition, beneficial ownership deconstruction, sanctions screening tuning, and PEP risk adjudication.

Testing and Records: Every employee must achieve a minimum passing grade of 80% on the post-training examination. Training attendance logs, syllabi, and test scores are retained in the compliance archives for ten (10) years in WORM-compliant storage.
