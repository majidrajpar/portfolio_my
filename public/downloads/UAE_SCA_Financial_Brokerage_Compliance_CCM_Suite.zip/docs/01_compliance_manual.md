# [Entity Name L.L.C.]
# Compliance Manual and Regulatory Governance Framework
# Trade Name: [Trading Name] | SCA License: [SCA License No.]

## 1. Corporate Governance and Statutory Licensing Framework

### 1.1 Legal Structure and Authorisation
[Entity Name L.L.C.] (trading as [Trading Name], the Firm) is a regulated financial institution incorporated in the United Arab Emirates under UAE Federal Decree-Law No. (32) of 2021 on Commercial Companies. The Firm operates as an authorized financial brokerage licensed and regulated by the Securities and Commodities Authority (SCA) under Chairman of the Authority's Board of Directors Decision No. (13/Chairman) of 2021 on the Rulebook of Financial Activities and Reconciliation of Status, as amended by Chairman Decision No. (01/R.M) of 2023 and associated circulars.

Under UAE commercial legislation and SCA licensing regulations, Category 1 financial activities typically contemplate a Public Joint Stock Company (PJSC) or Private Joint Stock Company (PrJSC) corporate form. The Firm operates under an approved corporate charter and explicit regulatory dispensation issued by the SCA permitting its Limited Liability Company (L.L.C.) structure, subject to stringent governance, board independence covenants, and heightened capital adequacy reserves equivalent to joint-stock institutions.

The Firm holds statutory authorizations across two core licensing schedules:

Category 1: Trading Broker in Over-The-Counter (OTC) Derivatives and Spot Foreign Exchange. Under this category, the Firm is authorized to engage in broker-dealer activities, execute client orders, act as principal, market maker, or risk-mitigating agent in OTC contracts for differences (CFDs), spot foreign exchange, deliverable commodities, and cash-settled financial derivatives, and maintain segregated custody of client funds directly linked to margined positions.

Category 5: Financial Consultation and Financial Analysis. Under this category, the Firm is authorized to provide regulated investment advice, independent financial research, macroeconomic reports, market commentary, technical chart analysis, and non-discretionary recommendations on securities, commodities, foreign exchange markets, and derived financial structures.

The Firm maintains its principal operational headquarters in the United Arab Emirates, subject to continuous supervision by the SCA, the Financial Intelligence Unit (FIU) of the UAE Central Bank, and relevant federal regulatory authorities.

### 1.2 Statutory Paid-Up Capital and Guarantee Baselines
Pursuant to Article 6 and Schedule 1 of SCA Decision No. (13/Chairman) of 2021, the Firm maintains permanent paid-up share capital and statutory regulatory guarantees strictly calibrated to its authorized activities:

Category 1 Paid-Up Capital Baseline: The Firm maintains a minimum statutory paid-up share capital of AED 30,000,000 to support its principal dealing, market making, clearing, and client asset custody operations.

Category 5 Paid-Up Capital Baseline: The Firm maintains an allocated paid-up share capital between AED 1,000,000 and AED 2,000,000 dedicated to financial consultation and financial analysis operations.

Statutory Bank Guarantee: The Firm maintains an unconditional, irrevocable bank guarantee issued by a CBUAE-licensed commercial bank in favor of the Securities and Commodities Authority in the statutory amount of AED 5,000,000 (minimum statutory threshold between AED 1,000,000 and AED 5,000,000 depending on dealing tier). This guarantee serves as a first-demand regulatory indemnity protecting client assets and market counterparties against institutional default.

Capital Adequacy Early Warning Trigger: In addition to the statutory 100% net capital requirement, the Firm enforces an internal early warning threshold set at 120% of the statutory net capital adequacy requirement. If net capital declines to or below 120%, the Risk Officer triggers an automated capital alert to the Board Audit and Risk Committee, initiating an immediate liquidity review and deploying contingency capital buffers before any statutory breach occurs.

### 1.3 Scope and Enforceability
This Compliance Manual sets forth the mandatory operating standards, statutory governance structures, and control requirements governing all operations, employees, officers, approved persons, and contracted vendors of the Firm. Adherence to this manual is a condition of employment and statutory appointment. Any violation, circumvention, or failure to remediate non-compliance exposes the individual and the Firm to administrative sanctions, monetary penalties, license suspension, or statutory disqualification by the SCA under Federal Law No. (4) of 2000 and subsequent regulations.

---

## 2. Governance Architecture and Statutory Control Functions

### 2.1 The Board of Directors
The Board of Directors (the Board) holds ultimate legal, fiduciary, and regulatory accountability for the operations, sound management, capital adequacy, and regulatory compliance of the Firm. The Board ensures that the Firm operates within the strict parameters of its SCA Category 1 and Category 5 licenses.

The Board is structured to ensure operational independence, consisting of executive directors, non-executive directors, and independent members meeting SCA fit-and-proper standards. The statutory responsibilities of the Board encompass:

Setting the strategic objectives, risk appetite limits, compliance governance charter, and operational controls of the Firm.

Approving all operational policies, compliance frameworks, AML/CFT risk assessments, client money segregation procedures, and financial crime prevention manuals.

Ensuring adequate operational, technological, and human capital resources are permanently allocated to the compliance, internal control, risk management, internal audit, and finance departments.

Convening quarterly at a minimum to receive, review, and formally resolve upon compliance findings, anti-money laundering reporting, internal audit recommendations, and regulatory correspondence.

Directly supervising and evaluating the performance of statutory approved persons, including the Senior Executive Officer, the Compliance Officer, the Money Laundering Reporting Officer, the Risk Officer, and the Head of Internal Audit.

### 2.2 Board Committees
To discharge its governance mandates, the Board operates two permanent committees operating under written terms of reference approved by the SCA:

Audit and Risk Committee: Composed entirely of non-executive and independent directors, this committee oversees financial reporting integrity, the adequacy of internal accounting and technical controls, engagement of external statutory auditors, review of risk management architecture, and monitoring of capital adequacy reserves. The Head of Internal Audit reports functionally directly to this committee.

Compliance and Ethics Committee: Oversees regulatory compliance performance, conducts direct oversight over the statutory Compliance Officer and MLRO, reviews regulatory inspections and audit tracking registers, adjudicates material conflicts of interest, and reviews whistleblowing submissions.

---

## 3. Statutory Officer Roles and Approved Person Requirements

Under the SCA Rulebook, individuals discharging designated controlled functions must satisfy fit-and-proper criteria, complete mandatory regulatory qualification examinations, and obtain formal prior written approval from the SCA before assuming statutory duties. The Firm maintains strict functional independence across all control desks.

```
       +-------------------------------------------------------------+
       |                     Board of Directors                      |
       +-------------------------------------------------------------+
               |                                            |
               v                                            v
+-------------------------------+             +---------------------------+
|   Audit & Risk Committee      |             | Compliance & Ethics Comm. |
+-------------------------------+             +---------------------------+
    |               |                                       |
    | Functional    +-------------------+-------------------+
    | Line                              |
    v                                   v
+-----------------------+      +---------------------------------+
| Head of Internal Audit|      |     Senior Executive Officer    |
|   (SCA Approved)      |      |         (SCA Approved)          |
+-----------------------+      +---------------------------------+
                                                |
          +-------------------------------------+-----------------------------------+
          |                                     |                                   |
          v                                     v                                   v
+-----------------------+             +-----------------------+           +-------------------+
|  Compliance Officer   |             |   Money Laundering    |           |   Risk Officer    |
|    (SCA Approved)     |             |   Reporting Officer   |           |  (SCA Approved)   |
|   [CISI Certified]    |             |    (SCA Approved)     |           | [CISI Certified]  |
+-----------------------+             +-----------------------+           +-------------------+
```

### 3.1 Mandatory Regulatory Examinations (CISI Modules)
In compliance with SCA Approved Person regulations, all candidates for statutory controlled functions must successfully complete the prescribed Chartered Institute for Securities & Investment (CISI) qualification modules prior to submitting their licensing application to the SCA:

CISI UAE Financial Rules and Regulations: Mandatory statutory certification for the Senior Executive Officer, Compliance Officer, MLRO, Risk Officer, and Dealing Desk trading representatives.

CISI Capital Markets / International Introduction to Securities and Investment: Mandatory technical certification verifying market mechanics, derivative valuation, risk management, and order routing systems.

Maintaining Active Qualifications: The Compliance Department tracks continuous professional development (CPD) credits and annual renewal of CISI credentials for all approved personnel.

### 3.2 The Senior Executive Officer (SEO)
The Senior Executive Officer holds primary executive accountability for directing the day-to-day operations, business strategy, technological resilience, and statutory compliance of the Firm. The SEO ensures that executive management enforces all board-approved policies and maintains uncompromised independence for internal control functions.

### 3.3 The Compliance Officer
The Compliance Officer is an SCA-approved statutory appointment holding unrestricted access to all corporate books, records, software platforms, and personnel. The Compliance Officer reports administratively to the Senior Executive Officer and functionally to the Board Compliance and Ethics Committee.

Core statutory duties include:

Continuous Regulatory Monitoring: Identifying, assessing, and documenting changes in UAE Federal legislation, SCA circulars, Central Bank decrees, and international regulatory baselines affecting OTC derivatives and retail forex broking.

Policy Architecture Maintenance: Reviewing and updating internal compliance policies, standard operating procedures, and risk appetite parameters at least annually, or immediately upon regulatory revision.

Regulatory Inquiries and Notifications: Managing all formal communications, licensing applications, regulatory reporting, and statutory notifications required by the SCA.

Conduct of Business Oversight: Ensuring that client classification, marketing communications, product design, financial promotions, appropriateness scoring algorithms, and margin execution practices adhere to SCA retail protection mandates.

Training and Education: Administering mandatory compliance induction and annual refresher training to all employees, maintaining attendance logs and knowledge test results.

Annual Compliance Assessment Report: Formulating and submitting the comprehensive statutory annual compliance review to the Board and the SCA.

### 3.4 The Money Laundering Reporting Officer (MLRO)
The MLRO is an SCA-approved statutory officer responsible for the daily execution and oversight of the AML/CFT and Sanctions Compliance Program. The MLRO operates with complete operational autonomy and has a direct reporting line to the Board and the UAE Financial Intelligence Unit (FIU). The MLRO may be assisted by a Deputy MLRO holding equal statutory qualifications.

Core statutory duties include:

Financial Crime Architecture: Establishing, maintaining, and supervising the implementation of customer due diligence, enhanced due diligence, sanctions screening rails, and automated transaction monitoring systems.

Suspicious Transaction Adjudication: Investigating internal suspicion reports raised by employees or automated monitoring engines, determining whether grounds for suspicion exist, and documenting all decision logs.

Regulatory Reporting via goAML and TFS: Preparing and submitting Suspicious Activity Reports (SARs) and Suspicious Transaction Reports (STRs) directly to the FIU through the goAML portal, and submitting Fund Freeze Reports (FFR) to the Executive Office for Control and Non-Proliferation (EOCN) via the TFS portal without internal corporate interference or client tipping-off.

Sanctions Enforcement: Ensuring real-time and continuous batch screening of all onboarded clients, counterparties, and beneficial owners against the UAE Local Terrorist List and the UN Consolidated Sanctions List.

### 3.5 The Risk Officer
The Risk Officer is an SCA-approved professional responsible for establishing, executing, and stress-testing the enterprise risk framework covering market, credit, operational, liquidity, technical, and counterparty risks.

Core statutory duties include:

Market and Liquidity Risk Monitoring: Continuous real-time tracking of open derivative contract exposures, hedging book imbalances, liquidity provider concentrations, and currency settlement risks.

Segregation Deficit and Capital Adequacy Oversight: Monitoring daily client asset segregation calculations, verifying firm capital coverage ratios, and ensuring capital reserves strictly exceed SCA minimum regulatory net capital limits and early warning triggers.

Operational Infrastructure Risk: Stress-testing matching engine performance, latency metrics, execution slippage distributions, failover redundancy, and cybersecurity safeguards.

Negative Balance Protection Safeguards: Ensuring execution engine stop-out protocols, automated margin close-out triggers, and margin calls function without latency or execution gaps during high-volatility sessions.

### 3.6 The Head of Internal Audit
The Head of Internal Audit is an SCA-approved officer who leads the independent third line of defense. To preserve complete objectivity, the Head of Internal Audit reports functionally directly to the Board Audit and Risk Committee and administratively to the Senior Executive Officer.

Core statutory duties include:

Formulating and executing an annual risk-based internal audit plan approved by the Board Audit and Risk Committee.

Conducting independent evaluations of internal accounting controls, client money segregation workflows, trading engine integrity, and operational risk frameworks.

Auditing the effectiveness of the Compliance and AML/CFT control programs, assessing adherence to SCA licensing conditions.

Submitting comprehensive internal audit reports directly to the Board Audit and Risk Committee with tracked management remediation action plans.

---

## 4. Licensing Boundaries, Chinese Walls, and Permissible Activities

### 4.1 Permitted Activities Under Category 1
The Firm is strictly authorized to execute, facilitate, and clear contracts within the following defined scope:

Trading brokerage in contracts for differences (CFDs) where the underlying assets consist of foreign currencies, precious metals, crude oil, standard energy products, sovereign bonds, approved single-stock equities, and major stock market indices.

Spot foreign exchange brokerage executed on a deliverable or margin-settled basis through authorized liquidity providers.

Margin-based OTC financial derivatives provided to retail clients, professional clients, and eligible counterparties in compliance with statutory leverage caps and margin rules.

Direct order routing, straight-through processing (STP), and matched-principal risk mitigation through institutional counterparty liquidity tiers pre-approved by the Risk Officer.

### 4.2 Permitted Activities Under Category 5
The Firm is authorized to conduct advisory and analytical services limited to:

Formulating written market commentary, macroeconomic overviews, technical chart analyses, and economic calendar evaluations made available through approved digital portals or registered client feeds.

Publishing investment research reports on underlying instruments, commodities, and foreign exchange currency trends, provided reports contain mandatory conflict-of-interest declarations and disclaimer statements.

Providing non-discretionary investment recommendations based on defined suitability and appropriateness profiles of professional clients.

### 4.3 Structural Chinese Walls: Principal Dealing Desk vs Research
To prevent market abuse, front-running, and systemic conflicts between the Category 1 Principal Dealing Desk and Category 5 Financial Research analysts, the Firm enforces strict physical, technological, and informational Chinese Walls:

Physical Separation: The Category 5 research and consultation team is physically partitioned from the Category 1 dealing desk, market execution screens, and liquidity risk management units. Access to research offices and dealing rooms is controlled by independent biometric electronic access control systems.

Logical and Technological Segregation: Research personnel operate on an isolated Virtual Local Area Network (VLAN) with distinct server permissions. Research analysts have zero logical or administrative access to the order management system (OMS), client trade blotters, open position books, client margin records, or liquidity provider execution queues.

Pre-Publication Dealing Blackouts: Dealing desk personnel and proprietary risk traders are subject to an absolute trading blackout on any asset, instrument, or derivative contract that is the subject of impending firm research. Dealing desks are prohibited from taking directional, anticipatory, or speculative hedging positions in instruments covered by pending research publications from the moment an analyst initiates research drafting until broad public dissemination.

Mandatory Statutory Disclosure Statement: Every research report, market update, or technical commentary published under Category 5 must include an un-redacted, prominent statutory disclosure declaring:
"[Entity Name L.L.C.] holds an SCA Category 1 license and acts as principal, market maker, and liquidity provider in OTC derivatives and spot foreign exchange contracts referencing the underlying instruments analyzed in this report. This publication is distributed strictly for general informational purposes and does not constitute an individualized investment recommendation or an offer to buy or sell financial instruments."

### 4.4 Prohibited Activities
The Firm, its employees, and contracted agents are strictly prohibited from engaging in the following conduct:

Discretionary Portfolio Management: Operating managed trading accounts, pooled investment vehicles, or accepting power-of-attorney to trade on behalf of any client.

Guaranteed Returns: Providing any oral or written representation, assurance, or guarantee of investment returns, capital preservation, or risk-free profits on derivative transactions.

Proprietary Front-Running: Entering proprietary hedging or directional orders ahead of pending client orders to exploit expected price movements.

Unlicensed Deposit Taking: Accepting cash, physical currency, negotiable instruments, cashier's cheques, or non-traceable virtual assets.

Off-Platform Bilateral Transactions: Facilitating trades outside the integrated pricing, risk, and clearing systems authorized by the SCA.

Unregistered Sub-Brokers and Affiliates: Onboarding clients through unregulated lead generators or third parties executing unauthorized solicitation within the UAE.

---

## 5. Regulatory Engagement, Early Warning Triggers, and Supervisory Relations

### 5.1 Principles of Regulatory Engagement
The Firm maintains an open, transparent, proactive, and cooperative posture with the SCA and domestic supervisory authorities. The Firm adheres to the fundamental principle that the regulator must be notified immediately of any event, incident, or discovery that materially impacts the operational resilience, financial stability, client asset safety, or regulatory compliance of the authorized firm.

### 5.2 Mandatory Regulatory Immediate Notifications
The Compliance Officer must lodge a formal written notification to the SCA within twenty-four (24) hours of the occurrence of any of the following triggers:

Capital Adequacy Breach: Any reduction of the Firm's net capital below 100% of the minimum statutory capital threshold required for Category 1 and Category 5 licenses.

Capital Adequacy Early Warning Trigger (120%): If internal monitoring detects net capital declining below 120% of the statutory threshold, the Risk Officer and Compliance Officer issue an immediate early warning report to senior management and prepare contingency capital protocols.

Client Asset Segregation Deficit: Any occurrence where client platform equity exceeds segregated funds held in approved client bank accounts, regardless of whether the shortfall was resolved by buffer capital within the same day.

Liquidity Provider Default Trigger: Any bankruptcy, insolvency, trading suspension, material credit downgrade, or operational default of an authorized institutional clearing broker or liquidity provider holding client margin escrow, notified to the SCA within two (2) hours.

Cybersecurity Incident and Data Breach Triggers: Any unauthorized network intrusion, ransomware infection, data exfiltration, or DDoS event that disrupts trading platforms or compromises client data, notified to the SCA and domestic cybersecurity authorities immediately and in all cases within twenty-four (24) hours.

Statutory Personnel Resignations or Removals: Resignation, dismissal, or suspension of the Senior Executive Officer, Compliance Officer, MLRO, Risk Officer, Head of Internal Audit, Financial Controller, or a member of the Board of Directors.

Material Legal or Law Enforcement Action: Service of legal process, criminal investigation, dawn raid, court attachment order, or supervisory enforcement notice against the Firm or its directors.

Significant Fraud or Dishonesty: Detection of internal fraud, employee theft, rogue trading, or systemic financial misconduct exceeding AED 50,000 in aggregate.

### 5.3 Scheduled Regulatory Reporting Matrix

```
+-----------------------------------+--------------------+------------------------+------------------+
| Report Description                | Frequency          | Regulatory Recipient   | Submission Deadline |
+-----------------------------------+--------------------+------------------------+------------------+
| Client Money & Asset Segregation  | Daily / Monthly    | SCA Financial Control  | T+1 09:00 (int.) / |
| Reconciliation Return             |                    |                        | 5th of each month|
| Net Capital & Capital Adequacy    | Monthly            | SCA Supervision        | 10 business days |
| Calculation Return                |                    |                        | following month  |
| Transaction Volumes & Exposure    | Quarterly          | SCA Markets Division   | 15 business days |
| Reporting by Instrument Class     |                    |                        | following quarter|
| Retail Client Complaints Log      | Quarterly          | SCA Conduct of Business| 15 business days |
| and Resolution Tracking           |                    |                        | following quarter|
| Annual Audited Financial Stmts    | Annually           | SCA / Public Registry  | March 31         |
| & External Auditor Review         |                    |                        | (90 days FY end) |
| Annual External Client Asset      | Annually           | SCA Financial Control  | March 31         |
| Assurance Audit Report            |                    |                        | (90 days FY end) |
| Annual Compliance Officer Report  | Annually           | Board of Directors /   | 60 calendar days |
| and Compliance Review             |                    | SCA Supervision        | from FY end      |
| Annual External AML Assurance     | Annually           | FIU / SCA Financial    | June 30          |
| Inspection Report                 |                    | Crime Supervision      |                  |
+-----------------------------------+--------------------+------------------------+------------------+
```

### 5.4 Management of Regulatory Inspections
During any routine, thematic, or surprise inspection conducted by the SCA:

The Compliance Officer serves as the lead inspection coordinator, providing inspectors with immediate access to premises, terminals, platform logs, records, and relevant staff.

The IT and operations teams must provide full read-access to core database tables, client onboarding dossiers, goAML logs, order routing audit trails, and reconciliation sheets.

All requests for documents, interview transcripts, and platform extracts must be logged in a dedicated Regulatory Inspection Register.

The Compliance Officer maintains minutes of all entry and exit interviews with SCA inspectors, providing a formal remediation action plan to the Board within ten (10) business days following receipt of the preliminary inspection report.

---

## 6. Personal Account Dealing (PAD) Policy

### 6.1 Purpose and Coverage
The Personal Account Dealing (PAD) policy governs personal investment activities conducted by directors, officers, employees, seconded staff, and their connected persons (spouses, dependent children, and entities controlled by them). This framework mitigates front-running, trading on inside information, and market abuse.

### 6.2 Pre-Clearance Mandate and Duplicate Contract Notes
Every covered person must submit an electronic PAD Pre-Clearance Request to the Compliance Department prior to executing any personal trade in single-stock equities, debt instruments, exchange-traded derivatives, or leveraged OTC contracts where the underlying is tradeable on the Firm's platform.

The Compliance Officer reviews each request against pending institutional client flow, the Firm's restricted trading list, and upcoming research publications.

Approval, if granted, is valid only for twenty-four (24) hours from the timestamp of authorization.

Mandatory Duplicate Broker Notes: All covered persons must direct their external executing brokers to transmit duplicate contract notes, transaction confirmations, and periodic statements directly to the Compliance Department via dedicated compliance ingestion feeds.

### 6.3 Mandatory Pre- and Post-Publication Blackout Windows
Covered persons are subject to strict publication blackouts surrounding the Firm's Category 5 research:

Pre-Publication Blackout: Covered persons are strictly barred from trading any security, currency, commodity, or derivative referenced in a research report during the forty-eight (48) hours preceding its public release.

Post-Publication Blackout: Covered persons are strictly barred from executing personal transactions in referenced instruments for twenty-four (24) hours following public dissemination of the research.

### 6.4 Prohibited Personal Trading Activities
Covered persons are strictly prohibited from:

Trading contracts in any asset class for which the covered person possesses material non-public information (MNPI), pending order flow information, or internal financial analysis prior to broad public dissemination.

Executing personal transactions on platforms of competing retail brokers without prior written declaration and approval from the Compliance Officer.

Engaging in short-term speculative round-trips on identical instruments within a holding window of less than thirty (30) calendar days, unless an explicit exemption is granted by the Compliance Officer to prevent financial distress.

Front-running or shadowing client orders identified through internal market execution screens or back-office access.

---

## 7. Conflicts of Interest Framework

### 7.1 Identification and Assessment of Conflicts
The Firm systematically identifies, documents, and prevents or manages conflicts of interest that arise between:

The Firm and its clients.

A client of the Firm and another client.

An employee, director, or statutory officer and the Firm or its clients.

The operational units executing client trades and the units managing liquidity risk or financial research.

### 7.2 Conflict Management Mechanisms
The Firm applies organizational and technical controls to neutralize identified conflicts:

Structural Separation and Chinese Walls: Physical and logical access controls separate Category 5 Financial Analysis and Consultation personnel from Category 1 Dealing and Risk Management desks. Analysts have zero visibility into open client order books, position concentrations, or liquidity provider execution queues.

Remuneration Controls: Quantitative dealing desk compensation is decoupled from client trading losses. Dealing desk personnel, account managers, and customer service staff are strictly barred from receiving commissions, bonuses, or remuneration tied to client net margin losses or client churn rates.

Gifts and Inducements Thresholds: Employees are prohibited from offering or accepting any gifts, hospitality, entertainment, or financial benefits from clients, liquidity providers, or vendors that exceed AED 500 in value. Any permitted benefit under AED 500 must be declared in the corporate Gift Register within two (2) business days and approved by the Compliance Officer.

---

## 8. Record Retention, Off-Channel Archiving, and Data Privacy Reconciliation

### 8.1 Statutory Mandate and UAE PDPL Reconciliation
Pursuant to UAE Federal Commercial Companies Law No. (32) of 2021, Federal Decree-Law No. (20) of 2018 on AML/CFT, and the SCA Rulebook, the Firm enforces a strict minimum retention period of ten (10) years for all operational, financial, compliance, client identification, and transactional records.

Reconciliation with Federal Decree-Law No. (45) of 2021 on Personal Data Protection (PDPL): Under Articles 4 and 24 of the UAE PDPL, the processing and retention of personal data is lawful without data subject consent where processing is necessary for the controller to fulfill statutory legal obligations under applicable federal legislation. The statutory obligations imposed by the SCA and Federal AML/CFT law mandate the continuous maintenance of client records for ten (10) years. Consequently, statutory record-keeping covenants legally override client "Right to Erasure" or data deletion requests under the PDPL. If a client submits an erasure request, personal data is restricted from commercial processing but retained in immutable compliance archives until the statutory 10-year clock expires.

The 10-year retention clock commences:

For customer identification, CDD, and EDD files: upon the formal date of account closure or the formal cessation of the business relationship.

For transactional records, order logs, and execution histories: from the date of settlement or contract expiration.

For regulatory correspondence, compliance registers, and board minutes: from the date of final formal resolution or closing of the regulatory inquiry.

### 8.2 Scope of Records Subject to 10-Year Retention
The following records are captured in write-once-read-many (WORM) immutable storage:

Client Identity and Verification: Passports, Emirates IDs, utility bills, corporate registries, UBO declarations, source-of-funds verification, PEP screening records, risk scorecards, and appropriateness questionnaires.

Platform Telemetry and Order Audit Trails: Timestamped logs capturing order receipt, routing, price quotes, slippage calculation, fill execution, modifications, cancellations, stop-out liquidations, and margin adjustments accurate to the millisecond.

Client Communications and Instructions: All electronic mail, web portal ticket messages, live chat sessions, and telephone recordings of customer support, dealing desks, and compliance consultations. All voice lines used by dealing desks are continuously recorded.

Financial Books and Bank Operations: Daily client asset segregation reconciliations, bank account statements, Swift confirmations, clearing broker statements, ledgers, journals, audited financial statements, and buffer equity movements.

Regulatory and Governance Documentation: Minutes of the Board of Directors, Audit and Risk Committee records, goAML internal suspicion files, SAR/STR filings, internal audit working papers, and correspondence with the SCA.

### 8.3 Off-Channel Communications Archiving Policy
Employees, directors, and contractors are strictly barred from using unapproved, non-archived communication channels for any business, trading, or client-related discourse. This prohibition encompasses personal WhatsApp, Telegram, Signal, WeChat, SMS, personal email, and social media direct messaging.

All client-facing discussions, investment consultations, trading inquiries, and execution instructions must occur exclusively through registered corporate communication systems: corporate email, authorized CRM messaging, verified portal tickets, or recorded corporate telephone lines.

Mobile devices utilized by approved persons and dealing staff are enrolled in Mobile Device Management (MDM) software configured with automated enterprise archiving solutions that mirror and index all communication streams into compliance storage.

### 8.4 Technical Archival Safeguards (AWS S3 Object Lock in Compliance Mode)
All historical records and telemetry streams are archived within UAE-domiciled cloud infrastructure utilizing Amazon Web Services (AWS) S3 buckets configured with S3 Object Lock in Compliance Mode.

Compliance Mode Enforcement: Under Compliance Mode, a protected object version cannot be overwritten, altered, or deleted by any user, including AWS root account credentials or enterprise administrators, throughout the statutory 10-year retention period.

Cryptographic Verification: Every uploaded archival batch is sealed with a SHA-256 cryptographic hash and chained into an immutable ledger to guarantee evidentiary integrity before regulatory bodies and UAE courts.

Destructive deletion after the expiry of the 10-year statutory period requires formal authorization signed jointly by the Compliance Officer, the Legal Counsel, and the Chief Technology Officer.

---

## 9. Whistleblowing and Compliance Escalation Protocols

### 9.1 Whistleblower Protections
The Firm maintains a secure, independent whistleblowing channel accessible to all employees, contractors, and external counterparties. Whistleblowers reporting genuine suspicions of financial crime, market manipulation, client asset misappropriation, breach of SCA rules, or systemic non-compliance are granted statutory protections against dismissal, demotion, harassment, or retaliation.

### 9.2 Reporting Channels and Escalation Workflow
Reports can be submitted anonymously through an encrypted third-party whistleblowing portal or directly to the Chairman of the Compliance and Ethics Committee.

The Compliance Officer maintains a secure Whistleblowing Case Register. All investigations must be completed within thirty (30) calendar days of receipt. Findings indicating material breaches of law or SCA regulations are submitted directly to the Board of Directors and subsequently to the SCA without redaction.
