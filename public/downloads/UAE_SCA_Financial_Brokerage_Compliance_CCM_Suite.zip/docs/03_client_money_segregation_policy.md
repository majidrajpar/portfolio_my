# [Entity Name L.L.C.]
# Client Money and Asset Segregation Policy
# Trade Name: [Trading Name] | SCA License: [SCA License No.]

## 1. Statutory Framework and Regulatory Mandate

### 1.1 Regulatory Foundations
[Entity Name L.L.C.] (trading as [Trading Name], the Firm) establishes this Client Money and Asset Segregation Policy in strict adherence to the regulatory regime established by the Securities and Commodities Authority (SCA) under Chairman of the Authority's Board of Directors Decision No. (13/Chairman) of 2021 on the Rulebook of Financial Activities and Reconciliation of Status, Chairman Decision No. (01/R.M) of 2023, and applicable SCA circulars governing client asset protection for Category 1 authorized brokers.

The primary objective of this policy is the absolute protection of client assets, guaranteeing that all client money is held on statutory trust, completely segregated from the Firm's own corporate and operational capital, immune from corporate creditor claims, and immediately available for distribution to clients in the event of corporate insolvency, wind-up, or license revocation.

### 1.2 Fundamental Fiduciary Principles
Client money is held in a fiduciary capacity under statutory trust. The Firm does not hold any beneficial, legal, or equitable title to client funds.

Client money shall never be utilized to finance corporate overhead, operational expenses, regulatory capital buffers, proprietary investments, or the trading positions of other clients.

Co-mingling client funds with the Firm's proprietary operational funds is strictly illegal under UAE law and constitutes a severe regulatory infraction carrying immediate license suspension and criminal liability under Federal Commercial and Penal statutes.

---

## 2. Approved Depository Institutions, Asset Allocation Caps, and Concentration Limits

### 2.1 Criteria for Approved Banks
Client segregated funds must be deposited exclusively with credit institutions that meet the following statutory criteria:

The bank must be a fully licensed commercial bank incorporated and operating within the United Arab Emirates, directly regulated and supervised by the Central Bank of the United Arab Emirates (CBUAE).

The bank must possess an investment-grade long-term credit rating (minimum BBB+ or equivalent by Moody's, S&P, or Fitch).

The bank must maintain operational clearing connectivity with the UAE Central Bank's UAE Funds Transfer System (UAEFTS) and Immediate Payment Instruction (IPI) rails.

### 2.2 Depository Allocation and Concentration Caps
To safeguard client assets from institutional and counterparty insolvency, the Firm enforces strict regulatory allocation ceilings:

Domestic Bank Holding Floor (Minimum 60%): At least sixty percent (60%) of all segregated client assets must be held permanently in direct client trust bank accounts at CBUAE-regulated commercial banks.

Clearing Broker Escrow Ceiling (Maximum 40%): No more than forty percent (40%) of aggregate client funds may be deployed as segregated margin escrow with institutional clearing brokers or liquidity providers. These escrow funds may only be deployed to margin active, client-facing hedging positions directly mirroring open retail client exposure.

Single-Bank Concentration Cap (Maximum 50%): To prevent single-institution failure risk, client cash placed across domestic commercial banks must be distributed such that no single commercial banking institution holds more than fifty percent (50%) of total domestic client bank deposits.

Annual Trust Letter Re-Certification: Every depository relationship (commercial banks and clearing brokers) must be formally re-certified annually. The Compliance Department re-executes and verifies statutory bank acknowledgment letters across all holding institutions during Quarter 1 of each calendar year.

### 2.3 Statutory Bank Acknowledgment Letters
Prior to transferring any client funds into an account maintained at an approved depository, the Firm must obtain a legally binding, signed Bank Acknowledgment Letter executed by authorized senior bank officers. The letter must explicitly confirm and state that:

All funds deposited in the designated accounts are held by the Firm on statutory trust for the exclusive benefit of its clients.

The bank holds no legal or equitable interest in, charge over, right of retention, lien, or right of set-off or combination against funds held in the account for any liability, indebtedness, or obligation owed by the Firm or any third party to the bank.

The account title distinctly designates its segregated fiduciary nature, styled formally as: "[Entity Name L.L.C.] - Client Segregated Trust Account".

The bank will not permit any overdraft, credit extension, or negative balance on the account.

```
+---------------------------------------------------------------------------------------------------+
|                            CLIENT MONEY BANKING & CUSTODY TOPOLOGY                                |
+---------------------------------------------------------------------------------------------------+
|                                                                                                   |
|                 +---------------------------------------------------------------+                 |
|                 |                   Trading Client (Retail/Pro)                 |                 |
|                 +---------------------------------------------------------------+                 |
|                                     | Inbound Deposit (UAEFTS / Cards)                            |
|                                     v                                                             |
|                 +---------------------------------------------------------------+                 |
|                 |   CBUAE Licensed Commercial Banks (Tier-1 UAE Banks)          |                 |
|                 |   Account: "[Entity Name L.L.C.] - Client Trust Account"      |                 |
|                 |   - MINIMUM 60% of Total Client Assets Allocated Here         |                 |
|                 |   - Max 50% Concentration Cap at any Single Bank              |                 |
|                 |   - Absolute Statutory Waiver of Set-Off & Lien               |                 |
|                 +---------------------------------------------------------------+                 |
|                            |                                       |                              |
|      Client Daily Margin   |                                       | Firm Buffer Pre-Funding      |
|      Settlement Flow       |                                       | (Segregation Buffer >= 10%,  |
|      (Max 40% Cap)         |                                       |  Absolute Floor AED 5M)      |
|                            v                                       v                              |
|  +-----------------------------------+             +-----------------------------------+          |
|  | Institutional Clearing Custodians |             | Operational Bank Account          |          |
|  | (Approved Hedging Brokers)        |             | (Proprietary Working Capital)     |          |
|  | - MAXIMUM 40% Allocation Cap      |             | - ZERO Co-Mingling Permitted      |          |
|  | - Segregated Omnibus Margin Line  |             | - Pre-Funds Uncleared Card Float  |          |
|  | - Pre-Approved Hedging Escrow     |             | - Corporate Overhead & Payroll    |          |
|  +-----------------------------------+             +-----------------------------------+          |
+---------------------------------------------------------------------------------------------------+
```

---

## 3. Scope of Client Money and Segregation Architecture

### 3.1 Definition of Client Money
Client money encompasses all cash amounts received by the Firm from clients, or credited to clients through trading operations, including:

Initial and variation margin deposits transferred to secure derivative positions.

Unrealized profits generated from open contracts for differences (CFDs) and spot foreign exchange transactions.

Realized net trading profits, rollover financing credits, and positive contract adjustments.

Free, unencumbered cash balances retained in trading platform accounts awaiting deployment or withdrawal.

Dividends, cash distributions, or corporate action proceeds received in respect of underlying derivative securities.

### 3.2 Permissible Depository Locations
Client funds may reside only in two types of pre-approved holding architectures:

Primary Client Segregated Bank Accounts: Direct trust accounts maintained at approved UAE commercial banks (holding at least 60% of total client assets).

Approved Institutional Clearing Escrow Accounts: Segregated omnibus margin accounts maintained with Tier-1 institutional clearing brokers or liquidity providers (capped at 40% of total client assets). Institutional clearing brokers must provide equivalent statutory acknowledgment letters confirming omnibus segregation and absolute waiver of set-off.

---

## 4. Dual-Tier Daily Reconciliation Architecture and Calculations

### 4.1 Daily Reconciliation Mandate and Timeline
The Finance and Treasury Department, under direct supervision of the Compliance Officer and Risk Officer, executes an exhaustive dual-tier reconciliation of all client funds every business day. 

The reconciliation must be completed, reconciled, and formally approved by 09:00 UAE Time on business day T+1, reflecting settled ledger and platform states as of 23:59:59 UAE Time on business day T.

```
+---------------------------------------------------------------------------------------------------+
|                         DUAL-TIER DAILY RECONCILIATION ARCHITECTURE                               |
+---------------------------------------------------------------------------------------------------+
| TIER 1: INTERNAL PLATFORM-TO-LEDGER RECONCILIATION                                                |
| Target: Platform Net Client Equity vs General Ledger Account 2100 (Client Segregated Liability).  |
| Formula: Platform Net Equity - GL 2100 Settled Balance = 0.00 AED                                 |
| Objective: Validates platform execution engine data matches double-entry financial ledgers.       |
+---------------------------------------------------------------------------------------------------+
                                             |
                                             v
+---------------------------------------------------------------------------------------------------+
| TIER 2: EXTERNAL SEGREGATED RESOURCE RECONCILIATION                                               |
| Target: Total Client Equity Requirement (TCER) vs Total Segregated Asset Resources (TSAR).        |
| Formula: TSAR >= TCER + Statutory Firm Buffer Capital (>= 10% TCER, Min AED 5,000,000)            |
| Objective: Confirms physical cash in trust banks and clearing escrow covers all client claims.    |
+---------------------------------------------------------------------------------------------------+
```

### 4.2 Calculation of Total Client Equity Requirement (TCER)
The internal ledger calculation captures the total fiduciary obligation of the Firm toward every individual client account.

Uncleared Deposits in Transit Float Fix: Under no circumstances may uncleared card deposits or in-transit merchant funds be deducted from the TCER calculation. Deducting transit float artificially deflates the Firm's calculated fiduciary liability while clients trade against credited platform balances. Total Client Equity Requirement represents the gross mark-to-market fiduciary obligation across all client accounts:

$$TCER = \sum_{i=1}^{N} \max\left(0, CB_i + UPnL_i\right)$$

Where:

$CB_i$ is the cash balance credited to client account $i$ on the trading platform (including any trading credits authorized upon irreversible payment gateway authorization).

$UPnL_i$ is the mark-to-market net unrealized profit or loss of all open derivative and FX positions for client account $i$ at official daily close.

The maximum function ensures that any negative client equity (debit balance) is evaluated as zero in aggregate calculations, guaranteeing that a shortfall in one client's account is never offset by or financed using the surplus equity of another client.


Accounting Treatment of Pending Disbursements: In the daily operational reconciliation model, pending client disbursements (withdrawn from platform equity but pending banking transmission) may either be treated as an additive fiduciary commitment ($TCER = \sum \max(0, CB_i + UPnL_i) + Pending\_Disbursements$) against gross bank balances, or as an offset against depository resources ($TSAR = \sum Balance - Pending\_Disbursements$). Both treatments yield an identical Net Segregation Surplus ($TSAR - TCER$), with the additive model providing a prudentially higher statutory buffer calculation as implemented in the Master Reconciliation Model.

### 4.3 Total Segregated Asset Resources (TSAR)
The total external segregated resource is calculated strictly from verified, cleared depository statements:

$$TSAR = \sum Balance_{UAE\_Bank} + \sum Balance_{Clearing\_Escrow} - Pending\_Disbursements$$

Where:

$Balance_{UAE\_Bank}$ is the verified, cleared ledger balance in approved UAE client segregated trust accounts.

$Balance_{Clearing\_Escrow}$ is the verified balance held in approved segregated omnibus margin accounts with institutional liquidity providers (subject to the 40% aggregate cap).

$Pending\_Disbursements$ represents issued client withdrawals that have departed internal ledgers but have not yet cleared physical banking rails.

Uncleared PSP receivables are excluded from TSAR until settled in the trust bank account.

```
       +-------------------------------------------------------------+
       |   Internal Platform Ledger (T at 23:59:59 UAE Time)        |
       +-------------------------------------------------------------+
                                      |
                                      v
       +-------------------------------------------------------------+
       |   Calculate Total Client Equity Requirement (TCER)          |
       |   TCER = Sum(max(0, Cash Balance_i + Unrealized PnL_i))     |
       |   [Zero Deduction for In-Transit Float or Uncleared Cards]  |
       +-------------------------------------------------------------+
                                      |
                                      v
       +-------------------------------------------------------------+
       |   External Segregated Asset Verification (T at 23:59:59)    |
       |   TSAR = Cleared Bank Trust Balances (>=60%)                |
       |        + Clearing Broker Margin Escrow (<=40%)              |
       |        - Pending Disbursements                              |
       +-------------------------------------------------------------+
                                      |
                                      v
       +-------------------------------------------------------------+
       |   Reconciliation Test: TSAR >= TCER + Firm Buffer Capital   |
       |   Firm Buffer >= max(0.10 * TCER, AED 5,000,000)            |
       +-------------------------------------------------------------+
              |                                             |
      Surplus Verified                               Deficit Identified
              |                                             |
              v                                             v
  +-------------------------+                   +-------------------------+
  | Log Approved Daily Pack |                   | Immediate Buffer Top-Up |
  | Retain in WORM Storage  |                   | SCA Breach Notification |
  | (Sign-off by 09:00 T+1) |                   | (Zero De Minimis Rule)  |
  +-------------------------+                   +-------------------------+
```

---

## 5. Prudent Buffer Allocation Model and Segregation Deficit Remediation

### 5.1 The Prudent Buffer Allocation Model
To ensure that client deposits authorized through instant payment gateways or card acquirers are fully backed by physical segregated cash before bank settlement occurs, the Firm operates the Prudent Buffer Allocation Model:

The Firm injects and permanently maintains proprietary cash known as the Firm Buffer Capital directly within the primary UAE Client Segregated Trust Bank Account.

The Firm Buffer Capital must equal a minimum of ten percent (10%) of the total client equity requirement, subject to an absolute minimum floor of AED 5,000,000.

The Buffer Capital pre-funds the transit float created by uncleared card acquirer and PSP receivables. When a retail client deposits via credit card and receives instant trading equity, the Firm Buffer instantly absorbs the fiduciary margin obligation, ensuring TSAR continues to exceed TCER by the required statutory surplus at all times.

The Buffer Capital is contributed exclusively from the Firm's own post-tax operational capital and is segregated in accounting ledgers under Account 3100 "Firm Equity in Client Trust".

The Firm may not withdraw, reduce, or transfer any portion of the Buffer Capital if such action would cause the buffer ratio to drop below the 10% statutory reserve threshold or the AED 5,000,000 absolute floor.

### 5.2 Segregation Deficit Remediation (Zero De Minimis Threshold)
If at any point the daily reconciliation or continuous telemetry detects that Total Segregated Asset Resources (TSAR) fall below the Total Client Equity Requirement (TCER), a Segregation Deficit exists. The Firm enforces a zero de minimis policy:

Elimination of De Minimis Exceptions: No internal threshold (such as AED 100,000) permits withholding or delaying remediation or regulatory reporting. Any deficit of any magnitude represents a reportable fiduciary breach.

Immediate Liquidity Transfer: The Chief Financial Officer and Risk Officer must immediately authorize and execute an emergency wire from the Firm's Operational Working Capital Account to the Client Segregated Trust Account to eliminate the deficit and restore the 10% buffer.

Remediation Timeframe: The transfer must be credited to the Client Segregated Trust Account within two (2) hours of identification, and no later than 11:00 UAE Time on T+1.

Mandatory Regulatory Notification at 09:00 T+1: If any segregation deficit remains unresolved at 09:00 UAE Time on T+1, or if a deficit of any magnitude is detected during the daily reconciliation, the Compliance Officer must lodge a formal written incident notification to the SCA Supervision Department within twenty-four (24) hours, detailing the root cause, deficit magnitude, corrective cash injections, and preventative operational adjustments.

---

## 6. Treatment of Uncleared Funds, Card Deposits, and Acquiring Rails

### 6.1 Payment Service Providers and Acquiring Rails
When clients fund their trading accounts using credit cards, debit cards, or approved instant payment gateways:

Immediate Platform Credit vs Bank Availability: The platform may credit the client's internal trading balance upon receipt of an irreversible authorization code from the payment acquirer. However, physical cash does not clear into the bank account until settlement (typically T+1 to T+3).

Pre-Funding Mandate: Uncleared merchant receivables cannot be treated as qualifying segregated cash for external bank reconciliation. The Firm utilizes its Buffer Capital to pre-fund the client's equity requirement until the payment acquirer deposits the cash into the Client Segregated Trust Account.

Acquiring Rolling Reserves: Acquirer rolling reserves or security holdbacks maintained by payment gateways cannot be counted toward segregated client funds.

### 6.2 Strict Ban on Third-Party and Crypto Deposits
Under no circumstances shall the Firm accept client funding from:

Third-party bank accounts, corporate entities funding personal accounts, or accounts where the depositor name diverges from the verified client legal identity.

Cash deposits, cashier's checks, over-the-counter physical bank deposits, or postal money orders.

Unregulated virtual asset rails, anonymous cryptocurrency addresses, or non-custodial crypto payment gateways.

---

## 7. Operational Dual Control and Transfer Authorizations

### 7.1 Separation of Duties
To prevent fraudulent misappropriation or unauthorized movement of client assets, the Firm enforces strict separation of duties:

No single individual holds end-to-end authority to initiate, approve, and execute transfers out of client segregated accounts.

Compliance and Dealing Desk personnel are strictly barred from possessing banking portal payment entry or authorization permissions.

All outbound disbursements from the Client Segregated Trust Account require dual cryptographic approval:
- Level 1 Initiator: Senior Treasury / Operations Officer (verifying withdrawal legitimacy against platform margin status, settled ledger, and verified client identity).
- Level 2 Authorizer: Chief Financial Officer or approved Director (verifying bank recipient coordinates, absence of sanctions flags, and segregation buffer impact).

### 7.2 Permissible Outbound Disbursements
Funds may be withdrawn from the Client Segregated Trust Account exclusively for:

Executing verified client withdrawal instructions back to the client's verified personal bank account from which the original funds were derived.

Transferring necessary margin coverage to approved institutional clearing brokers to support open client derivative hedges, subject to the 40% aggregate ceiling.

Settling statutory broker trading commissions, spread markups, and overnight swap financing fees earned by the Firm, provided such fees are transferred directly to the Firm Operational Account and supported by daily fee run audit reports.

Withdrawing excess Firm Buffer Capital, provided the post-transfer buffer balance strictly complies with statutory capital reserve floors (>=10% TCER and >= AED 5,000,000).

---

## 8. Annual Client Asset Assurance and External Audit (March 31 Deadline)

### 8.1 Statutory External Client Asset Audit
In compliance with SCA regulations, the Firm undergoes an annual specialized Client Asset Assurance Audit executed by an independent, SCA-approved external auditing firm. The audit is conducted concurrently with the statutory financial year-end audit.

### 8.2 Scope of External Review
The external client asset assurance encompasses:

Direct independent circularization of all UAE banks and institutional clearing brokers holding client funds to confirm account title, balance, and acknowledgment letters.

Verification of depository concentration caps, confirming at least 60% of client assets remained in CBUAE banks, clearing broker escrow did not exceed 40%, and no single domestic bank held more than 50% of domestic client funds.

Sample-testing of daily segregation reconciliations across at least twenty-five (25) randomly selected dates throughout the fiscal year.

Evaluation of automated equity calculation engines, ensuring unrealized profits and losses are computed in accordance with international accounting standards (IFRS 9) and transit float was not deducted from TCER.

Verification that withdrawals were released exclusively to pre-verified client-owned accounts.

Review of buffer capital adequacy, confirming no un-remediated deficits occurred during the fiscal year.

The independent Auditor's Report on Client Asset Segregation is submitted directly to the Board of Directors and transmitted to the SCA by no later than March 31 of each calendar year (within 90 calendar days from fiscal year end).
