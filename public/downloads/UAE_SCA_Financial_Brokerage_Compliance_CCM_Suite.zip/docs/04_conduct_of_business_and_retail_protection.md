# [Entity Name L.L.C.]
# Conduct of Business and Retail Investor Protection Policy
# Trade Name: [Trading Name] | SCA License: [SCA License No.]

## 1. Regulatory Mandate and Scope of Protection

### 1.1 Purpose and Statutory Authority
[Entity Name L.L.C.] (trading as [Trading Name], the Firm) establishes this Conduct of Business and Retail Investor Protection Policy pursuant to Chairman of the Authority's Board of Directors Decision No. (13/Chairman) of 2021 on the Rulebook of Financial Activities and Reconciliation of Status, Chairman Decision No. (01/R.M) of 2023, and circulars issued by the Securities and Commodities Authority (SCA) governing trading brokers in over-the-counter (OTC) derivatives and spot foreign exchange.

This policy establishes operational, technical, and commercial standards designed to secure fair treatment for retail investors, mitigate structural information asymmetries, enforce prudential leverage ceilings, prevent client indebtedness through mandatory negative balance protection, enforce non-compensatory appropriateness qualification, and guarantee order execution integrity.

---

## 2. Client Categorisation Architecture

### 2.1 Statutory Client Categories
The Firm classifies every client into one of three distinct regulatory categories prior to opening any account or accepting trading instructions:

Retail Clients: Investors who do not satisfy the criteria of Professional Clients or Market Counterparties. Retail clients are granted the highest tier of statutory and conduct-of-business protection, including mandatory leverage caps, strict non-compensatory appropriateness testing, standardized risk disclosures, negative balance protection, and automated 50% margin close-out safeguards. All natural persons are treated as Retail Clients by default.

Professional Clients: Clients possessing the requisite financial experience, net worth, knowledge, and operational capability to evaluate derivative risk and bear significant investment losses. Professional Clients are sub-divided into Per Se Professional Clients (licensed financial institutions, institutional investment funds, sovereign wealth funds, and regulated brokers) and Elective Professional Clients (high-net-worth individuals and corporate entities meeting statutory qualification thresholds).

Market Counterparties: Eligible institutional entities, central banks, supranational organizations, and approved Category 1 brokers operating in wholesale financial markets.

### 2.2 Elective Professional Qualification Criteria
A Retail Client may be re-classified as an Elective Professional Client only if the client formally requests such re-classification in writing and the Firm verifies that the client satisfies the qualitative assessment and at least two (2) of the following three (3) quantitative criteria:

Significant Transaction Volume: The client has carried out transactions of significant size on derivative or currency markets at an average frequency of at least ten (10) trades per quarter over the preceding four (4) consecutive quarters.

Liquid Financial Portfolio: The client maintains a verified liquid financial investment portfolio (comprising cash deposits, money market instruments, equities, and debt securities, explicitly excluding real estate, physical personal property, or encumbered assets) exceeding AED 4,000,000 (or its foreign currency equivalent).

Professional Sector Experience: The client works, or has worked for at least one (1) year, in the financial services sector in a professional role requiring specific knowledge of leveraged derivative instruments, margined foreign exchange, or capital markets.

### 2.3 Opt-Up Procedure and Loss of Protections Warning
Before executing any re-classification to Elective Professional status:

The client must submit a signed Opt-Up Request Form affirming their intention to be treated as a Professional Client.

The Compliance Officer must provide the client with a clear, written statutory warning detailing the protections lost:
- Disapplication of retail statutory leverage caps (enabling higher leverage and higher risk of loss).
- Disapplication of mandatory appropriateness testing prior to executing transactions.
- Disapplication of automated negative balance protection (unless specifically agreed by contract).
- Modification of communication standards regarding financial promotions and risk disclosures.

The client must return a signed, independent written statement confirming: "I acknowledge that I am requesting to be classified as a Professional Client. I confirm that I understand the nature of the protections I will forfeit, and I am prepared to accept the resulting financial risks."

---

## 3. Non-Compensatory Appropriateness Assessment Framework

### 3.1 Non-Compensatory Architecture and Scoring Hurdles
The Firm executes an algorithmic Appropriateness Assessment for every prospective Retail Client prior to enabling live trading functionality or accepting margin deposits for OTC derivatives or spot foreign exchange contracts.

To ensure retail investors possess genuine technical comprehension of leveraged risk, the assessment is structured as a non-compensatory 3-part framework. A high net worth or high trading frequency in simple assets cannot compensate for a failure to understand derivative liquidation and leverage mechanics:

```
+---------------------------------------------------------------------------------------------------+
|                        NON-COMPENSATORY APPROPRIATENESS SCORING FRAMEWORK                         |
+-------------------------------------------------------+---------------+---------------------------+
| Assessment Section                                    | Maximum Score | Statutory Passing Hurdle  |
+-------------------------------------------------------+---------------+---------------------------+
| Part A: Derivative & Leverage Risk Mechanics          | 40 Points     | MANDATORY HARD HURDLE     |
| (Margin calls, stop-out 50%, gapping, slippage, swaps)|               | Minimum 35 / 40 Points    |
+-------------------------------------------------------+---------------+---------------------------+
| Part B: Historical Trading Experience & Volume        | 30 Points     | Evaluated in Aggregate    |
| (Frequency, asset classes, holding duration in OTC/FX)|               | (Part B + Part C)         |
+-------------------------------------------------------+---------------+---------------------------+
| Part C: Financial Capacity & Loss Tolerance           | 30 Points     | Evaluated in Aggregate    |
| (Annual income, liquid net worth, risk appetite)      |               | (Part B + Part C)         |
+-------------------------------------------------------+---------------+---------------------------+
| OVERALL QUALIFICATION REQUIREMENT                     | 100 Points    | (1) Part A >= 35 Points   |
|                                                       |               | (2) Total Score >= 70 Pts |
+-------------------------------------------------------+---------------+---------------------------+
```

```
       +-------------------------------------------------------------+
       |   Prospective Retail Client Submits Digital Application     |
       +-------------------------------------------------------------+
                                      |
                                      v
       +-------------------------------------------------------------+
       |   Dynamic Question Engine (Randomized 40-Question Pool)     |
       |   - Part A: Complex Derivative & Liquidation Mechanics      |
       |   - Part B: Historical Trading Velocity & Experience        |
       |   - Part C: Financial Standing & Loss Capacity              |
       +-------------------------------------------------------------+
                                      |
                                      v
       +-------------------------------------------------------------+
       |   Evaluation Stage 1: Part A Hard Hurdle Check              |
       +-------------------------------------------------------------+
              |                                             |
        Part A < 35 Points                           Part A >= 35 Points
              |                                             |
              v                                             v
  +-------------------------+                   +-------------------------+
  | IMMEDIATE FAIL          |                   | Evaluation Stage 2:     |
  | Total Score Disregarded |                   | Total Score >= 70 Check |
  | Trading Blocked         |                   +-------------------------+
  | 24h Cooling-Off Period  |                         |             |
  +-------------------------+             Total < 70  |             | Total >= 70
                                                      v             v
                                              +---------------+ +---------------+
                                              | FAIL          | | PASS          |
                                              | 24h Cooling   | | Live Trading  |
                                              | Off Enforced  | | Activated     |
                                              +---------------+ +---------------+
```

### 3.2 Dynamic Question Pool and Anti-Gaming Safeguards
The assessment engine draws questions dynamically from an active question pool containing a minimum of forty (40) psychometrically validated questions. The engine randomizes question selection, question sequence, and multiple-choice answer ordering for each applicant to eliminate answer-sharing, script bots, and pattern guessing.

### 3.3 Annual Re-Testing Cycle
Appropriateness certification is valid for a maximum duration of twelve (12) months. Every active Retail Client must retake and successfully pass the dynamic Appropriateness Assessment annually to maintain trading access. If a client fails the annual re-test or allows certification to lapse, the platform automatically locks the account to "Close-Only" mode, preventing new position entry while allowing orderly liquidation of open positions.

### 3.4 Failing Outcome and Cooling-Off Restrictions
Where an applicant scores below 35 points in Part A or below 70 points in aggregate:
- The system immediately flags the application as "Not Appropriate" and presents a non-dismissible statutory warning: "Based on your assessment responses, trading in leveraged OTC derivatives and spot foreign exchange is not appropriate for your investment profile. You are at high risk of losing your entire capital."
- The system blocks deposits and live order execution.
- A mandatory cooling-off period of twenty-four (24) hours is enforced before any re-assessment can be initiated.
- Re-testing is strictly capped at a maximum of two (2) attempts within any thirty (30) calendar day window.

---

## 4. Retail Leverage Restrictions and Hedged Position Margining

### 4.1 Statutory Leverage Ceilings
The Firm enforces non-negotiable statutory leverage caps across all Retail Client accounts, hard-coded directly into the platform matching engine:

```
+----------------------------------------------------+------------------+-------------------+
| Underlying Instrument Class                        | Maximum Permitted| Minimum Initial   |
|                                                    | Leverage Ratio   | Margin Percentage |
+----------------------------------------------------+------------------+-------------------+
| Major Foreign Exchange Currency Pairs              | 30:1             | 3.33%             |
| (USD, EUR, JPY, GBP, CAD, CHF, AUD)                |                  |                   |
+----------------------------------------------------+------------------+-------------------+
| Non-Major Foreign Exchange Pairs, Gold (XAU),      | 20:1             | 5.00%             |
| and Tier 1 Major Stock Market Indices              |                  |                   |
+----------------------------------------------------+------------------+-------------------+
| Commodities (Excluding Gold) and                   | 10:1             | 10.00%            |
| Tier 2 Minor Stock Market Indices                  |                  |                   |
+----------------------------------------------------+------------------+-------------------+
| Individual Single-Stock Equities and Debt Securities| 5:1             | 20.00%            |
+----------------------------------------------------+------------------+-------------------+
| Permitted Crypto-Asset Derivatives or Other Assets | 2:1              | 50.00%            |
+----------------------------------------------------+------------------+-------------------+
```

### 4.2 Index Tier Classification Schedule
To prevent regulatory ambiguity, stock market indices are categorized into two explicit tiers:

Tier 1 Major Indices (20:1 Maximum Leverage / 5.00% Initial Margin):
- S&P 500
- Dow Jones Industrial Average (DJIA 30)
- Nasdaq 100
- FTSE 100
- DAX 40
- CAC 40
- Nikkei 225
- Euro Stoxx 50

Tier 2 Minor Indices (10:1 Maximum Leverage / 10.00% Initial Margin):
- Russell 2000
- ASX 200
- Hang Seng Index
- Regional Middle East and North Africa indices
- Emerging market equity indices
- Specialized sector and thematic equity indices

### 4.3 Mandatory 50% Gross Margin Requirement on Hedged Retail Positions
To prevent retail clients from circumventing leverage ceilings or accumulating unchecked exposure through offsetting trades, the Firm enforces a mandatory 50% Gross Hedged Margin Rule:

Zero Margin Relief Ban: The platform matching engine is strictly prohibited from granting 100% margin relief (zero required margin) on fully or partially hedged retail positions (e.g., holding 1.0 lot Long and 1.0 lot Short on the same contract).

Mandatory 50% Gross Calculation: For every hedged position pair, the required used margin is calculated at a minimum of fifty percent (50%) of the total gross margin required for both individual legs:

$$\text{Required Margin}_{\text{Hedged}} = 0.50 \times \left( \text{Margin}_{\text{Long Leg}} + \text{Margin}_{\text{Short Leg}} \right)$$

This requirement guarantees that retail clients maintain adequate capital reserves to absorb sudden spread widening, overnight rollover adjustments, or liquidity gaps when positions are closed or market spreads uncross during illiquid sessions.

---

## 5. Margin Maintenance, Margin Calls, and Stop-Out (50% Rule)

### 5.1 Real-Time Margin Level Calculation
The trading platform computes client margin levels continuously in real time using the following formula:

$$\text{Margin Level} = \left( \frac{\text{Total Account Equity}}{\text{Total Required Used Margin}} \right) \times 100$$

Where Total Account Equity is the sum of cash deposits, realized profits, and mark-to-market unrealized profit and loss across all open contracts.

### 5.2 Margin Call Notifications (80% and 100% Thresholds)
Pre-Warning (100% Margin Level): When a retail client's account equity equals 100% of the total required margin, the platform issues an automated digital alert notifying the client that available free margin is exhausted.

Formal Margin Call (80% Margin Level): When account equity drops to 80% of required margin, the platform triggers an urgent multi-channel Margin Call alert (in-platform banner, push notification, and SMS), warning the client that position liquidation will commence if margin levels continue to decline toward 50%.

### 5.3 Mandatory 50% Margin Close-Out (Stop-Out) Protocol
Pursuant to SCA retail investor protection standards, the Firm implements an automated Margin Close-Out Rule set at fifty percent (50%).

Mandatory Execution: The matching engine must automatically terminate one or more of a retail client's open derivative positions the moment the account Margin Level falls to or below 50%.

Algorithmic Liquidation Sequence: The liquidation algorithm operates without manual human intervention. The engine liquidates open positions in descending order of current floating loss (the position exhibiting the largest unrealized loss is closed first), continuing position liquidations until the account Margin Level recovers above 50%.

Zero Discretion: The dealing desk possesses zero discretion to delay, override, or cancel the automated stop-out engine.

---

## 6. Mandatory Negative Balance Protection

### 6.1 Absolute Loss Limitation Guarantee
The Firm provides an unconditional guarantee of Negative Balance Protection on an account-by-account basis to every Retail Client.

Under no circumstances can a Retail Client incur a debt or obligation to pay money to the Firm in excess of the funds deposited in their trading account.

The maximum possible aggregate financial loss for a Retail Client is strictly capped at the total monetary balance deposited into and held within the client's trading account at the time of position execution.

### 6.2 Negative Balance Remediation Mechanism
In the event that an extreme market gap, flash crash, weekend opening price divergence, or market illiquidity causes positions to be closed at prices that drive total account equity into a negative balance (debit balance):

The trading platform matching engine instantly locks the account to prevent further order entry.

The automated core ledger flags the debit balance.

The Firm's Treasury system initiates an immediate compensatory ledger adjustment crediting the client's account from the Firm's proprietary operational reserve, restoring the account balance to zero (AED 0.00).

The remediation must be executed automatically within twenty-four (24) hours of position liquidation.

The Firm is strictly barred from pursuing the client for recovery of the negative balance, selling the debt to third-party collectors, or deducting the deficit from independent accounts held by the client unless explicit cross-collateralization terms apply under professional status.

---

## 7. Risk Disclosures and Marketing Conduct

### 7.1 Standardised Mandatory Risk Warning
All marketing materials, website landing pages, mobile application interfaces, digital advertisements, social media posts, and promotional brochures must display a prominent, standardized risk disclosure. The disclosure must be presented in a font size at least equal to the predominant body text and displayed with equal visual prominence:

"Risk Warning: Complex financial products, including contracts for differences (CFDs) and leveraged foreign exchange contracts, carry a high degree of risk and can result in the rapid loss of your capital due to leverage. Between 70% and 80% of retail investor accounts lose money when trading CFDs with this provider. You should consider whether you understand how CFDs work and whether you can afford to take the high risk of losing your money."

### 7.2 Fair, Clear, and Not Misleading Communications
All marketing communications published or distributed by the Firm must adhere to strict conduct guidelines:

Prohibition of Deceptive Claims: Communications must never state or imply that leveraged derivative trading is safe, low-risk, simple, or a reliable vehicle for passive income or wealth accumulation.

Balanced Presentation: Any mention of potential financial gains or upside trading opportunities must be accompanied by an equally prominent description of corresponding downside risks and capital loss vulnerabilities.

Prohibition of Trading Incentives and Gamification: The Firm is strictly prohibited from offering monetary bonuses, deposit matching schemes, trading fee credits, lottery rewards, trading gifts, or gamification features designed to encourage retail clients to open accounts, increase deposit sizes, or amplify trading turnover.

---

## 8. Best Execution, Order Handling, and Slippage Transparency

### 8.1 Best Execution Mandate
The Firm takes all sufficient steps to achieve the best possible execution result for client orders, evaluating:

Execution Price: Continuously aggregating pricing feeds from multiple Tier-1 liquidity providers to construct a competitive bid-ask spread.

Speed and Likelihood of Execution: Maintaining high-capacity trading infrastructure with low round-trip latency to minimize requotes.

Total Transaction Costs: Disclosing all spreads, commissions, and swap fees prior to order submission.

### 8.2 Prohibition of Asymmetric Slippage
Market slippage occurs when an order is executed at a price different from the price requested, typically during rapid price movement or market illiquidity.

Symmetric Pass-Through Mandate: The execution engine must treat slippage symmetrically. If market liquidity allows an order to be filled at a price more favorable to the client than requested (positive slippage), the full price improvement must be credited to the client.

Strict Prohibition of Asymmetric Skewing: The Firm is prohibited from programming algorithms or execution logic that passes negative slippage to clients while absorbing or retaining positive slippage for the Firm's proprietary account.

### 8.3 Public Execution Quality Reporting
The Firm publishes an annual Execution Quality and Venue Report on its public website, detailing:

Top five (5) execution venues and liquidity providers utilized by contract volume.

Summary of execution quality achieved, including average execution speed (in milliseconds), fill rates, and percentage distribution of trades experiencing positive slippage, zero slippage, and negative slippage.

---

## 9. Complaint Handling Timelines and Regulatory Escalation

### 9.1 Complaints Infrastructure
The Firm maintains an independent Complaints Management Unit operating under direct supervision of the Compliance Officer. Retail clients may submit formal complaints free of charge via an encrypted online portal, electronic mail, or registered post.

```
+---------------------------------------------------------------------------------------------------+
|                             COMPLAINT RESOLUTION TIMELINE & STAGES                                |
+---------------------------------------------------------------------------------------------------+
| Stage 1: Receipt & Acknowledgment (Within 48 Hours)                                              |
|          Issue unique tracking ID; verify complainant identity and trading ledger.                |
+---------------------------------------------------------------------------------------------------+
| Stage 2: Substantive Technical Investigation (Days 3 to 14)                                       |
|          Compliance and Dealing Desks inspect millisecond server logs, ticks, and fills.         |
+---------------------------------------------------------------------------------------------------+
| Stage 3: Formal Final Response (Within 15 Business Days)                                          |
|          Comprehensive written resolution detailing findings, remedial adjustments, or grounds     |
|          for rejection, along with formal notice of right to escalate to the SCA.                 |
+---------------------------------------------------------------------------------------------------+
| Extended Stage: Exceptional Complex Cases (Up to 30 Business Days Maximum)                       |
|                 Interim update issued; formal notice sent to SCA Supervision Department.          |
+---------------------------------------------------------------------------------------------------+
```

### 9.2 Statutory Response Timelines
Acknowledgment: The Firm issues a formal written acknowledgment receipt containing a unique tracking reference number within forty-eight (48) hours of receiving a complaint.

Investigation: The Compliance Department conducts an objective review of platform server tick logs, order execution timestamps, telephone voice recordings, and digital chat records.

Final Response: The Firm delivers a formal, detailed written Final Response within fifteen (15) business days of complaint receipt. The response must clearly detail the investigation findings, corrective financial adjustments (if warranted), or the factual and regulatory rationale for rejecting the complaint.

Exceptional Extensions: In cases involving complex cross-border banking tracing or institutional liquidity disputes, the investigation period may be extended up to a maximum of thirty (30) business days, provided an interim explanation is issued to the complainant and logged with the SCA.

### 9.3 Escalation to the Securities and Commodities Authority
Every Final Response letter issued to a Retail Client must clearly inform the client of their statutory right to escalate the matter to the Securities and Commodities Authority if they remain dissatisfied with the Firm's resolution:

"If you are not satisfied with our final decision or the resolution proposed, you have the right to lodge a formal complaint with the Securities and Commodities Authority (SCA) through their official dispute portal at www.sca.gov.ae or by contacting the SCA Investor Protection Department."
